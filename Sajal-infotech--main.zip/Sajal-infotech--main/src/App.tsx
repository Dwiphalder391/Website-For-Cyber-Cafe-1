import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import Footer from './components/Footer';
import ServiceRequestPage from './components/ServiceRequestPage';
import ServicesPage from './components/ServicesPage';
import AdminPanel from './components/AdminPanel';
import SupportWidget from './components/SupportWidget';
import UserDashboard from './components/UserDashboard';
import LanguageSelector from './components/LanguageSelector';
import LazySection from './components/LazySection';
import { AuthProvider } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { useSiteSettings } from './hooks/useSiteSettings';
import { useState, useEffect, lazy, Suspense } from 'react';
import { AnimatePresence } from 'motion/react';
import * as motion from 'motion/react-client';

const Services = lazy(() => import('./components/Services'));
const Contact = lazy(() => import('./components/Contact'));

import { Globe } from 'lucide-react';
import { Toaster } from 'react-hot-toast';
import { playSound } from './lib/sounds';
import PageTransition from './components/PageTransition';

import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import StoreClosedModal from './components/StoreClosedModal';
import BackButtonHandler from './components/BackButtonHandler';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

import { themes, ThemeKey } from './lib/themes';

function ThemeManager() {
  const { settings } = useSiteSettings();
  
  useEffect(() => {
    const themeKey = (settings?.theme as ThemeKey) || 'default';
    const selectedTheme = themes[themeKey] || themes.default;
    const root = document.documentElement;
    
    root.style.setProperty('--theme-primary', selectedTheme.colors.primary);
    root.style.setProperty('--theme-secondary', selectedTheme.colors.secondary);
    root.style.setProperty('--theme-neutral1', selectedTheme.colors.neutral1);
    root.style.setProperty('--theme-neutral2', selectedTheme.colors.neutral2);
    root.style.setProperty('--theme-accent', selectedTheme.colors.accent);
    root.style.setProperty('--theme-text', selectedTheme.colors.text);
  }, [settings?.theme]);

  return null;
}

function GlobalEffects() {
  useEffect(() => {
    const handleGlobalClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('button') || target.closest('a')) {
        playSound('click');
      }
    };
    document.addEventListener('click', handleGlobalClick);
    return () => document.removeEventListener('click', handleGlobalClick);
  }, []);

  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = ''; // Setting returnValue triggers the browser's exit confirmation dialog
      return '';
    };
    
    // Check if the user is using the back button
    let isPushState = false;
    window.addEventListener('popstate', (e) => {
      // We could potentially show a custom modal here, but `beforeunload` is more reliable for leaving the site
    });

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, []);

  return null;
}

function Preloader() {
  const { settings, isLoaded } = useSiteSettings();
  const logoUrl = settings?.logoUrl || "https://storage.googleapis.com/aistudio-uploaded-blobs/Zz11c2Vycy82NDUyMTYwMTgzMDQvYmxvYnMvYXNzZXRfanlsdWxib3VlNWV5MTRxMQ.webp";
  
  return (
    <motion.div
      key="splash"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.05, filter: "blur(8px)" }}
      transition={{ duration: 0.6, ease: "easeInOut" }}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-sajal-primary overflow-hidden"
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="flex flex-col items-center gap-6"
      >
        <div className="bg-white p-4 rounded-2xl shadow-[0_0_60px_rgba(255,255,255,0.2)]">
          {isLoaded ? (
             <img src={logoUrl} alt="Sajal Infotech Logo" className="h-16 w-16 object-contain" referrerPolicy="no-referrer" />
          ) : (
             <div className="h-16 w-16" />
          )}
        </div>
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white tracking-tight leading-none mb-2">Sajal Infotech</h1>
          <p className="text-sajal-neutral1 text-xs font-bold tracking-[0.35em] uppercase">Cyber Cafe Services</p>
        </div>
      </motion.div>
      <motion.div 
        className="absolute bottom-16 w-56 h-1.5 bg-sajal-primary border border-sajal-secondary/20 rounded-full overflow-hidden shadow-inner"
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
      >
        <motion.div 
          className="h-full bg-sajal-secondary shadow-[0_0_15px_rgba(160,125,84,0.6)]"
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
        />
      </motion.div>
    </motion.div>
  );
}

function HomePage() {
  const location = useLocation();
  useEffect(() => {
    if (location.hash) {
      setTimeout(() => {
         const id = location.hash.replace('#', '');
         const element = document.getElementById(id);
         if (element) {
            const top = element.getBoundingClientRect().top + window.scrollY;
            window.scrollTo({ top: top - 110, behavior: 'smooth' });
         }
      }, 100);
    }
  }, [location]);

  return (
    <>
      <Hero />
      <LazySection id="services" placeholderHeight="min-h-screen">
        <Services />
      </LazySection>
      <LazySection id="contact" placeholderHeight="min-h-[500px]">
        <Contact />
      </LazySection>
    </>
  );
}

function AppContent() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      {/* @ts-ignore */}
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><HomePage /></PageTransition>} />
        <Route path="/services" element={<PageTransition><ServicesPage /></PageTransition>} />
        <Route path="/request" element={<PageTransition><ServiceRequestPage /></PageTransition>} />
        <Route path="/request/:serviceId" element={<PageTransition><ServiceRequestPage /></PageTransition>} />
        
        {/* Admin routes */}
        <Route path="/admin" element={<PageTransition><AdminPanel /></PageTransition>} />
        <Route path="/dashboard" element={<PageTransition><UserDashboard /></PageTransition>} />
        
        {/* Legal Routes */}
        <Route path="/privacy-policy" element={<PageTransition><PrivacyPolicy /></PageTransition>} />
        <Route path="/terms-of-service" element={<PageTransition><TermsOfService /></PageTransition>} />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  const { isLoaded } = useSiteSettings();
  const [showSplash, setShowSplash] = useState(true);
  const [languageSelected, setLanguageSelected] = useState<boolean>(
    () => localStorage.getItem('languageSelected') === 'true'
  );

  useEffect(() => {
    // Show splash screen for 0.8 seconds after DB settings are loaded
    if (!isLoaded) return;
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [isLoaded]);

  return (
    <BrowserRouter>
      <LanguageProvider>
        <AuthProvider>
          <GlobalEffects />
          <ThemeManager />
          <BackButtonHandler />
          <StoreClosedModal />
          <ScrollToTop />
          <Toaster position="top-center" toastOptions={{ style: { background: '#fff', color: '#1e293b', fontWeight: 'bold' } }} />
          <div className="min-h-screen bg-sajal-neutral2 font-sans text-sajal-text scroll-smooth selection:bg-sajal-secondary selection:text-white">
            <AnimatePresence mode="wait">
              {showSplash ? (
                <Preloader key="splash" />
              ) : !languageSelected ? (
                /* @ts-ignore */
                <LanguageSelector key="language" onSelect={() => setLanguageSelected(true)} />
              ) : (
                <motion.div
                  key="main"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className="flex flex-col min-h-screen"
                >
                  <Header />
                  <main className="flex-grow">
                    <AppContent />
                  </main>
                  <Footer />
                  <SupportWidget />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </AuthProvider>
      </LanguageProvider>
    </BrowserRouter>
  );
}


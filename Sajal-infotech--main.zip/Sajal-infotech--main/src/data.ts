export const reviewsData = [
  {
    id: '1',
    author: 'Arup S.',
    rating: 5,
    text: 'Best cyber cafe in Kadambagachi! They helped me fill out my college admission forms flawlessly. Very professional and helpful.',
    date: '2 months ago',
  },
  {
    id: '2',
    author: 'Debashis M.',
    rating: 5,
    text: 'Exceptional computer training center. I joined the Tally course and the instructors were very thorough. Highly recommended.',
    date: '4 months ago',
  },
  {
    id: '3',
    author: 'Priya R.',
    rating: 4,
    text: 'Very fast service for printouts and passport size photos. They always help with Aadhaar and PAN related work smoothly.',
    date: '6 months ago',
  },
  {
    id: '4',
    author: 'Rahul B.',
    rating: 5,
    text: 'Great place for daily internet usage and ticket bookings. The staff is polite and the systems are very fast.',
    date: '1 year ago',
  },
];

export { servicesData } from './servicesData';

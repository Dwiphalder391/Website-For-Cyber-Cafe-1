import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { ref, onValue, set, update, get } from 'firebase/database';
import { Settings, Users, Inbox, MessageCircle, Save, ChevronDown, Filter } from 'lucide-react';
import * as motion from 'motion/react-client';
import { toast } from 'react-hot-toast';
import { playSound } from '../lib/sounds';

export default function AdminPanel() {
  const { user, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<'requests' | 'settings' | 'users' | 'support'>('requests');

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-xl font-bold text-slate-500">Access Denied</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-12 flex">
      {/* Sidebar Navigation */}
      <div className="w-64 bg-white border-r border-slate-200 p-6 fixed h-full top-0 left-0 pt-32 hidden md:block z-10">
         <h2 className="text-xl font-bold text-sajal-primary mb-8">Admin Dashboard</h2>
         <nav className="space-y-2">
            {[
              { id: 'requests', label: 'Service Requests', icon: <Inbox className="w-5 h-5" /> },
              { id: 'support', label: 'Support Chats', icon: <MessageCircle className="w-5 h-5" /> },
              { id: 'settings', label: 'Site Settings', icon: <Settings className="w-5 h-5" /> },
              { id: 'users', label: 'User Management', icon: <Users className="w-5 h-5" /> }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all ${activeTab === tab.id ? 'bg-sajal-neutral2 text-sajal-secondary' : 'text-slate-500 hover:bg-slate-50 hover:text-sajal-primary'}`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
         </nav>
      </div>

      <div className="flex-1 md:ml-64 p-4 sm:p-8">
         {/* Mobile Navigation */}
         <div className="md:hidden flex overflow-x-auto gap-2 mb-6 pb-2 hide-scrollbar">
            {[
              { id: 'requests', label: 'Requests', icon: <Inbox className="w-4 h-4" /> },
              { id: 'support', label: 'Support', icon: <MessageCircle className="w-4 h-4" /> },
              { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
              { id: 'users', label: 'Users', icon: <Users className="w-4 h-4" /> }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex whitespace-nowrap items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all ${activeTab === tab.id ? 'bg-sajal-secondary text-white' : 'bg-white text-slate-500 border border-slate-200'}`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
         </div>
         {activeTab === 'requests' && <RequestsTab />}
         {activeTab === 'support' && <SupportTab />}
         {activeTab === 'settings' && <SettingsTab />}
         {activeTab === 'users' && <UsersTab />}
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// Sub-Components for Admin Tabs
// -------------------------------------------------------------

function RequestsTab() {
  const [requests, setRequests] = useState<any[]>([]);
  const [replyText, setReplyText] = useState<{ [key: string]: string }>({});
  const [savingId, setSavingId] = useState<string | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<string>('newest');

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };
  
  useEffect(() => {
    const reqRef = ref(db, 'requests');
    const unsub = onValue(reqRef, snap => {
      const data = snap.val();
      if (data) {
        const arr = Object.keys(data).map(key => ({ id: key, ...data[key] }));
        setRequests(arr);
      } else {
         setRequests([]);
      }
    });
    return () => unsub();
  }, []);

  const sortedRequests = [...requests].sort((a, b) => {
    if (sortBy === 'newest') return b.timestamp - a.timestamp;
    if (sortBy === 'oldest') return a.timestamp - b.timestamp;
    
    if (sortBy === 'appointmentFirst' || sortBy === 'appointmentLast') {
      // Parse dates based on appointmentDate (and maybe time)
      const tA = a.appointmentDate ? new Date(`${a.appointmentDate} ${a.appointmentTime ? a.appointmentTime.split(' - ')[0] : ''}`).getTime() : 0;
      const tB = b.appointmentDate ? new Date(`${b.appointmentDate} ${b.appointmentTime ? b.appointmentTime.split(' - ')[0] : ''}`).getTime() : 0;
      
      if (!tA && !tB) return b.timestamp - a.timestamp;
      if (!tA) return 1;
      if (!tB) return -1;
      
      return sortBy === 'appointmentFirst' ? tA - tB : tB - tA;
    }
    return 0;
  });

  const handleUpdate = async (id: string, currentStatus: string) => {
     setSavingId(id);
     try {
       const text = replyText[id];
       const updateData: any = {};
       
       if (text !== undefined) updateData.adminReply = text;
       
       if (Object.keys(updateData).length > 0) {
         await update(ref(db, `requests/${id}`), updateData);
       }
       toast.success("Status updated successfully");
       playSound('pop');
     } catch(e) {
       console.error(e);
       toast.error("Failed to update status");
     } finally {
       setSavingId(null);
     }
  };

  const handleStatusChange = async (id: string, status: string) => {
    await update(ref(db, `requests/${id}`), { status });
    toast.success(`Marked as ${status}`);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6 gap-4">
        <h3 className="text-lg font-bold">Recent Service Requests</h3>
        
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-500" />
          <select 
            value={sortBy} 
            onChange={(e) => setSortBy(e.target.value)}
            className="text-sm border border-slate-200 rounded-lg px-3 py-2 outline-none focus:ring-2 focus:ring-sajal-secondary/20 bg-slate-50"
          >
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="appointmentFirst">Appointment (Earliest)</option>
            <option value="appointmentLast">Appointment (Latest)</option>
          </select>
        </div>
      </div>
      
      <div className="space-y-3">
         {sortedRequests.length === 0 ? <p className="text-slate-500">No requests found.</p> : null}
         {sortedRequests.map(req => {
           const isExpanded = expandedId === req.id;
           return (
           <div key={req.id} className="rounded-xl border border-slate-100 bg-slate-50 hover:bg-slate-100 transition-colors overflow-hidden">
              <div 
                className="p-4 flex items-center justify-between cursor-pointer"
                onClick={() => toggleExpand(req.id)}
              >
                <div className="flex flex-col">
                  <h4 className="font-bold text-slate-800 text-sm md:text-base mb-0.5">{req.name}</h4>
                  <span className="text-xs font-semibold text-sajal-secondary">{req.serviceName || 'General Inquiry'}</span>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`text-xs font-bold px-2 py-1 rounded-full border hidden sm:inline-block ${req.status==='completed' ? 'bg-green-100 text-green-700 border-green-200' : req.status==='rejected' ? 'bg-red-100 text-red-700 border-red-200' : 'bg-amber-100 text-amber-700 border-amber-200'}`}>
                    {req.status ? req.status.charAt(0).toUpperCase() + req.status.slice(1) : 'Pending'}
                  </span>
                  <span className="text-xs text-slate-400 hidden sm:block">{new Date(req.timestamp).toLocaleDateString()}</span>
                  <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                </div>
              </div>

              {isExpanded && (
                <div className="p-4 bg-white border-t border-slate-100">
                  <div className="flex justify-between items-center mb-4">
                     <h4 className="font-bold text-slate-700 text-sm">Request Details</h4>
                     <select 
                       value={req.status || 'pending'} 
                       onChange={(e) => handleStatusChange(req.id, e.target.value)}
                       className={`text-xs font-bold px-3 py-1.5 rounded-lg outline-none cursor-pointer border ${req.status==='completed' ? 'bg-green-100 text-green-700 border-green-200' : req.status==='rejected' ? 'bg-red-100 text-red-700 border-red-200' : 'bg-amber-100 text-amber-700 border-amber-200'}`}
                     >
                       <option value="pending">Pending</option>
                       <option value="completed">Completed</option>
                       <option value="rejected">Rejected</option>
                     </select>
                  </div>
                  
                  <div className="grid sm:grid-cols-2 gap-3 text-sm mb-4">
                     <div className="bg-slate-50 p-2.5 rounded-lg"><strong>Name:</strong> {req.name}</div>
                     <div className="bg-slate-50 p-2.5 rounded-lg"><strong>Phone:</strong> <a href={`tel:${req.phone}`} className="text-blue-500 hover:underline">{req.phone}</a></div>
                     <div className="bg-slate-50 p-2.5 rounded-lg"><strong>Email:</strong> {req.email || 'N/A'}</div>
                     <div className="bg-slate-50 p-2.5 rounded-lg"><strong>Service ID:</strong> {req.serviceId || 'General'} {req.userId ? <span className="text-xs bg-sajal-secondary text-white px-2 py-0.5 ml-1 rounded">Registered User</span> : null}</div>
                     {req.appointmentDate && <div className="bg-amber-50 p-2.5 rounded-lg"><strong>Date:</strong> {new Date(req.appointmentDate).toLocaleDateString()}</div>}
                     {req.appointmentTime && <div className="bg-amber-50 p-2.5 rounded-lg"><strong>Time:</strong> {req.appointmentTime}</div>}
                  </div>
                  
                  <div className="text-sm bg-slate-50 p-3 rounded-lg border border-slate-100 mb-4 whitespace-pre-wrap">
                     {req.message}
                  </div>
                  
                  <div className="bg-slate-50 p-3 border border-slate-200 rounded-lg shadow-sm">
                     <label className="block text-xs font-bold text-slate-600 mb-2">Admin Reply to User (Optional):</label>
                     <div className="flex flex-col sm:flex-row gap-2">
                       <textarea
                         className="flex-1 text-sm p-3 border border-slate-200 rounded-lg outline-none resize-none bg-white focus:border-sajal-accent focus:ring-2 focus:ring-sajal-accent/20 transition-all"
                         rows={2}
                         placeholder="Type a response to the user..."
                         value={replyText[req.id] ?? (req.adminReply || '')}
                         onChange={e => setReplyText({ ...replyText, [req.id]: e.target.value })}
                       />
                       <button 
                         onClick={() => handleUpdate(req.id, req.status)}
                         disabled={savingId === req.id}
                         className="bg-sajal-secondary text-white px-6 py-2 font-bold rounded-lg text-sm hover:bg-sajal-primary transition-all disabled:opacity-50 active:scale-95 whitespace-nowrap"
                       >
                         {savingId === req.id ? 'Saving...' : 'Send Reply'}
                       </button>
                     </div>
                  </div>
                </div>
              )}
           </div>
           );
         })}
      </div>
    </div>
  );
}

function SupportTab() {
   const [chats, setChats] = useState<any[]>([]);
   const [selectedChat, setSelectedChat] = useState<string | null>(null);
   const [messages, setMessages] = useState<any[]>([]);
   const [reply, setReply] = useState('');
   const { user } = useAuth();

   useEffect(() => {
      const chatsRef = ref(db, 'supportChats');
      const unsub = onValue(chatsRef, snap => {
         const data = snap.val();
         if(data) {
            const arr = Object.keys(data).map(uid => ({ uid, ...data[uid].meta }));
            setChats(arr.sort((a:any, b:any) => b.lastTimestamp - a.lastTimestamp));
         }
      });
      return () => unsub();
   }, []);

   useEffect(() => {
     if(selectedChat) {
       const msgsRef = ref(db, `supportChats/${selectedChat}/messages`);
       const unsub = onValue(msgsRef, snap => {
         const data = snap.val();
         if(data) {
           setMessages(Object.keys(data).map(k => ({id:k, ...data[k]})).sort((a,b) => a.timestamp - b.timestamp));
         }
       });
       return () => unsub();
     }
   }, [selectedChat]);

   const sendReply = async (e: React.FormEvent) => {
     e.preventDefault();
     if(!reply.trim() || !selectedChat) return;
     const newMsgRef = ref(db, `supportChats/${selectedChat}/messages/${Date.now()}`);
     await set(newMsgRef, {
       text: reply,
       senderId: user?.uid,
       isAdmin: true,
       timestamp: Date.now()
     });
     setReply('');
   };

   return (
     <div className="grid md:grid-cols-3 gap-6 h-[70vh]">
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 overflow-y-auto">
           <h3 className="font-bold mb-4">Active Chats</h3>
           <div className="space-y-2">
             {chats.map(chat => (
               <div 
                 key={chat.uid} 
                 onClick={() => setSelectedChat(chat.uid)}
                 className={`p-3 rounded-xl cursor-pointer transition-colors ${selectedChat === chat.uid ? 'bg-sajal-neutral2 border border-sajal-secondary' : 'bg-slate-50 border border-slate-100 hover:bg-slate-100'}`}
               >
                 <div className="font-bold text-sm">{chat.userName || 'Anonymous'}</div>
                 <div className="text-xs text-slate-500 truncate">{chat.lastMessage}</div>
               </div>
             ))}
           </div>
        </div>
        <div className="md:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
           {selectedChat ? (
             <>
               <div className="p-4 border-b border-slate-100 font-bold bg-slate-50">Chatting with {chats.find(c => c.uid === selectedChat)?.userName}</div>
               <div className="flex-1 p-4 overflow-y-auto space-y-3">
                 {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.isAdmin ? 'justify-end' : 'justify-start'}`}>
                       <div className={`px-4 py-2 rounded-xl text-sm max-w-[75%] ${msg.isAdmin ? 'bg-sajal-secondary text-white rounded-br-none' : 'bg-slate-100 text-slate-800 rounded-bl-none'}`}>
                          {msg.text}
                       </div>
                    </div>
                 ))}
               </div>
               <form onSubmit={sendReply} className="p-4 border-t border-slate-100 flex gap-2">
                  <input type="text" value={reply} onChange={e => setReply(e.target.value)} className="flex-1 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none" placeholder="Reply as admin..." />
                  <button type="submit" className="px-4 py-2 bg-sajal-primary text-white rounded-xl font-bold">Send</button>
               </form>
             </>
           ) : (
             <div className="flex items-center justify-center h-full text-slate-400">Select a chat to start responding</div>
           )}
        </div>
     </div>
   );
}

import { Plus, Trash2, Upload, Image as ImageIcon, Palette, Store } from 'lucide-react';
import { themes, ThemeKey } from '../lib/themes';

function SettingsTab() {
  const [activeSubTab, setActiveSubTab] = useState<'logo' | 'banners' | 'theme'>('logo');
  const [logoUrl, setLogoUrl] = useState('');
  const [selectedTheme, setSelectedTheme] = useState<string>('default');
  const [isStoreClosed, setIsStoreClosed] = useState<boolean>(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [slides, setSlides] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({});

  useEffect(() => {
    get(ref(db, 'settings/site')).then(snap => {
       if(snap.exists()) {
          const data = snap.val();
          setLogoUrl(data.logoUrl || '');
          setSelectedTheme(data.theme || 'default');
          setIsStoreClosed(data.isStoreClosed || false);
          if(data.slides) {
             setSlides(data.slides);
          } else {
             // Fallback default
             setSlides([
               { title: 'Your Complete Digital Solutions Hub', description: 'From online forms to high-speed internet...', image: '', badge: 'Top Rated Cyber Cafe' }
             ]);
          }
       }
    });
  }, []);

  const handleFileUpload = async (file: File, path: string, progressKey: string): Promise<string> => {
    return new Promise((resolve, reject) => {
      setUploadProgress(prev => ({ ...prev, [progressKey]: 10 }));
      const reader = new FileReader();
      
      reader.onload = (e) => {
        setUploadProgress(prev => ({ ...prev, [progressKey]: 100 }));
        if (e.target?.result) {
          resolve(e.target.result as string);
        } else {
          reject(new Error("Failed to read file"));
        }
      };
      
      reader.onerror = () => reject(new Error("File read error"));
      
      // Basic image compression using canvas to avoid hitting database limits
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;
        
        // Max dimensions
        const MAX_WIDTH = 1920;
        const MAX_HEIGHT = 1080;
        
        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        
        const dataUrl = canvas.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.8);
        setUploadProgress(prev => ({ ...prev, [progressKey]: 100 }));
        resolve(dataUrl);
      };
      
      img.onerror = () => {
         // Fallback to direct read if image loading fails
         reader.readAsDataURL(file);
      };
      
      // Start the process
      reader.readAsDataURL(file);
      // intercept the reader to load image...
      const interceptReader = new FileReader();
      interceptReader.onload = (e) => {
         if(typeof e.target?.result === 'string') {
            img.src = e.target.result;
         }
      };
      interceptReader.readAsDataURL(file);
    });
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      let finalLogoUrl = logoUrl;
      if (logoFile) {
        finalLogoUrl = await handleFileUpload(logoFile, `site/logo_${Date.now()}`, 'logo');
      }

      const finalSlides = await Promise.all(slides.map(async (slide, index) => {
        let imageUrl = slide.image;
        if (slide.newFile) {
           imageUrl = await handleFileUpload(slide.newFile, `site/banner_${index}_${Date.now()}`, `banner_${index}`);
        }
        return {
           title: slide.title || '',
           description: slide.description || '',
           badge: slide.badge || '',
           image: imageUrl,
           primaryCta: slide.primaryCta || 'Explore Services',
           primaryHref: slide.primaryHref || '/services',
           secondaryCta: slide.secondaryCta || 'Contact Us',
           secondaryHref: slide.secondaryHref || '#contact',
        };
      }));

      const updates = {
        'settings/site/logoUrl': finalLogoUrl,
        'settings/site/theme': selectedTheme,
        'settings/site/isStoreClosed': isStoreClosed,
        'settings/site/slides': finalSlides,
      };
      await update(ref(db), updates);
      
      // Cleanup files state
      setLogoFile(null);
      setSlides(finalSlides);
      setLogoUrl(finalLogoUrl);
      setUploadProgress({});
      
      alert('Settings saved successfully!');
    } catch (e) {
      console.error(e);
      alert('Failed to save settings. Check if Storage is enabled and rules are correct.');
    } finally {
      setSaving(false);
    }
  };

  const addSlide = () => {
    setSlides([...slides, {
      title: 'New Banner',
      description: 'Banner description',
      badge: 'New',
      image: '',
      primaryCta: 'Explore Services',
      primaryHref: '/services',
      secondaryCta: 'Contact Us',
      secondaryHref: '#contact'
    }]);
  };

  const removeSlide = (index: number) => {
    setSlides(slides.filter((_, i) => i !== index));
  };

  const updateSlide = (index: number, key: string, value: any) => {
    const newSlides = [...slides];
    newSlides[index][key] = value;
    setSlides(newSlides);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-4 sm:p-6 max-w-4xl">
      <h3 className="text-xl font-bold mb-6 text-sajal-primary border-b pb-4">Brand & Assets</h3>
      
      <div className="flex flex-wrap gap-4 mb-8">
        <button 
          onClick={() => setActiveSubTab('logo')}
          className={`px-6 py-3 rounded-xl font-bold transition-all ${activeSubTab === 'logo' ? 'bg-sajal-secondary text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Site Logo
        </button>
        <button 
          onClick={() => setActiveSubTab('banners')}
          className={`px-6 py-3 rounded-xl font-bold transition-all ${activeSubTab === 'banners' ? 'bg-sajal-secondary text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Home Banners
        </button>
        <button 
          onClick={() => setActiveSubTab('theme')}
          className={`px-6 py-3 rounded-xl font-bold transition-all ${activeSubTab === 'theme' ? 'bg-sajal-secondary text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          App Theme
        </button>
        <button 
          onClick={() => setActiveSubTab('store' as any)}
          className={`px-6 py-3 rounded-xl font-bold transition-all ${activeSubTab === 'store' as any ? 'bg-sajal-secondary text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Store Settings
        </button>
      </div>

      <div className="space-y-6">
         {activeSubTab === 'theme' && (
           <motion.section initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="bg-slate-50 p-6 rounded-xl border border-slate-100">
              <h4 className="font-bold text-lg mb-4 flex items-center gap-2"><Palette className="w-5 h-5 text-sajal-secondary" /> Website Theme</h4>
              <p className="text-sm text-slate-500 mb-6">Select a color scheme for your application. This will be applied to all users immediately upon saving.</p>
              
              <div className="grid sm:grid-cols-2 gap-4">
                 {(Object.entries(themes) as [ThemeKey, typeof themes['default']][]).map(([key, themeObj]) => (
                   <div 
                      key={key}
                      onClick={() => setSelectedTheme(key)}
                      className={`p-4 rounded-xl border-2 cursor-pointer transition-all ${selectedTheme === key ? 'border-sajal-secondary bg-white shadow-md' : 'border-slate-200 bg-white hover:border-slate-300'}`}
                   >
                     <div className="font-bold text-slate-700 mb-3">{themeObj.name}</div>
                     <div className="flex h-12 rounded-lg overflow-hidden border border-slate-100">
                        <div className="flex-1" style={{ backgroundColor: themeObj.colors.primary }} />
                        <div className="flex-1" style={{ backgroundColor: themeObj.colors.secondary }} />
                        <div className="flex-1" style={{ backgroundColor: themeObj.colors.neutral1 }} />
                        <div className="flex-1" style={{ backgroundColor: themeObj.colors.accent }} />
                     </div>
                   </div>
                 ))}
              </div>
           </motion.section>
         )}

         {activeSubTab === 'logo' && (
           <motion.section initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="bg-slate-50 p-6 rounded-xl border border-slate-100">
              <h4 className="font-bold text-lg mb-4 flex items-center gap-2"><ImageIcon className="w-5 h-5 text-sajal-secondary" /> Update Site Logo</h4>
              <p className="text-sm text-slate-500 mb-6">This logo will be displayed on the header, preloader, and across the site.</p>
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
                 <div className="w-32 h-32 bg-white rounded-xl shadow-sm border border-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                    {logoFile ? (
                       <img src={URL.createObjectURL(logoFile)} alt="New Logo" className="w-24 h-24 object-contain" />
                    ) : logoUrl ? (
                       <img src={logoUrl} alt="Current Logo" className="w-24 h-24 object-contain" referrerPolicy="no-referrer" />
                    ) : (
                       <div className="text-slate-400 text-xs text-center p-2">No Logo</div>
                    )}
                 </div>
                 <div className="flex-1 w-full space-y-4">
                    <label className="flex items-center gap-2 px-5 py-3 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-sajal-neutral2 hover:text-sajal-primary transition-colors w-max shadow-sm group">
                       <Upload className="w-5 h-5 text-sajal-secondary group-hover:scale-110 transition-transform" />
                       <span className="text-sm font-semibold text-slate-700">Upload New Logo</span>
                       <input type="file" accept="image/*" className="hidden" onChange={e => {
                          if (e.target.files && e.target.files[0]) setLogoFile(e.target.files[0]);
                       }} />
                    </label>
                    {logoFile && <p className="text-sm font-semibold text-green-600">New logo selected, ready to save.</p>}
                    {uploadProgress['logo'] !== undefined && uploadProgress['logo'] < 100 && (
                       <div className="h-2 bg-slate-200 rounded-full overflow-hidden w-full max-w-xs">
                          <div className="h-full bg-sajal-secondary" style={{ width: `${uploadProgress['logo']}%` }}></div>
                       </div>
                    )}
                 </div>
              </div>
           </motion.section>
         )}

         {activeSubTab === 'banners' && (
           <motion.section initial={{opacity:0, y:10}} animate={{opacity:1, y:0}}>
              <div className="flex justify-between items-end mb-6">
                <div>
                   <h4 className="font-bold text-lg flex items-center gap-2 text-slate-800"><ImageIcon className="w-5 h-5 text-sajal-secondary" /> Home Banners</h4>
                   <p className="text-sm text-slate-500 mt-1">Manage the image sliders shown at the top of the homepage.</p>
                </div>
                <button onClick={addSlide} className="flex items-center gap-1.5 px-4 py-2.5 bg-sajal-neutral2 text-sajal-primary font-bold text-sm rounded-xl hover:bg-slate-200 hover:shadow-sm transition-all active:scale-95">
                  <Plus className="w-4 h-4" /> Add Banner
                </button>
              </div>
              
              <div className="space-y-8">
                 {slides.map((slide, index) => (
                    <div key={index} className="bg-slate-50 p-5 sm:p-8 rounded-2xl border border-slate-200 relative shadow-sm hover:shadow-md transition-shadow">
                       <button onClick={() => removeSlide(index)} className="absolute top-5 right-5 text-red-500 hover:text-red-700 p-2.5 hover:bg-red-50 rounded-xl transition-colors shadow-sm bg-white border border-red-100">
                          <Trash2 className="w-5 h-5" />
                       </button>
                       
                       <div className="flex items-center gap-3 mb-6">
                         <span className="flex items-center justify-center w-8 h-8 rounded-full bg-sajal-primary text-white font-bold text-sm">{index + 1}</span>
                         <h5 className="font-bold text-slate-700 text-lg">Banner Configuration</h5>
                       </div>
                       
                       <div className="grid lg:grid-cols-2 gap-8">
                          <div className="space-y-5">
                             <div>
                               <label className="block text-sm font-bold text-slate-600 mb-2">Banner Background Image</label>
                               <div className="flex flex-col sm:flex-row gap-4">
                                 <div className="w-full sm:w-40 h-28 bg-white border border-slate-200 rounded-xl flex items-center justify-center overflow-hidden shrink-0 shadow-inner">
                                   {slide.newFile ? (
                                      <img src={URL.createObjectURL(slide.newFile)} alt="New" className="w-full h-full object-contain bg-slate-900" />
                                   ) : slide.image ? (
                                      <img src={slide.image} alt="Current" className="w-full h-full object-contain bg-slate-900" />
                                   ) : (
                                      <ImageIcon className="w-8 h-8 text-slate-300" />
                                   )}
                                 </div>
                                 <div className="flex flex-col justify-center">
                                   <label className="flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors text-sm font-bold text-slate-700 shadow-sm w-full">
                                     <Upload className="w-4 h-4 text-sajal-secondary" /> Select Image
                                     <input type="file" accept="image/*" className="hidden" onChange={e => {
                                        if(e.target.files) updateSlide(index, 'newFile', e.target.files[0]);
                                     }} />
                                   </label>
                                   {slide.newFile && <span className="text-xs font-semibold text-green-600 mt-2 text-center">New image ready</span>}
                                 </div>
                               </div>
                               {uploadProgress[`banner_${index}`] !== undefined && uploadProgress[`banner_${index}`] < 100 && (
                                  <div className="mt-3 h-1.5 bg-slate-200 rounded-full overflow-hidden w-full max-w-xs">
                                     <div className="h-full bg-sajal-secondary" style={{ width: `${uploadProgress[`banner_${index}`]}%` }}></div>
                                  </div>
                               )}
                             </div>
                             
                             <div>
                                <label className="block text-sm font-bold text-slate-600 mb-1">Headline Title</label>
                                <input type="text" value={slide.title} onChange={e => updateSlide(index, 'title', e.target.value)} className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-white outline-none focus:border-sajal-secondary text-sm font-medium transition-colors" />
                             </div>
                             <div>
                                <label className="block text-sm font-bold text-slate-600 mb-1">Small Badge Text (e.g. 'Top Rated')</label>
                                <input type="text" value={slide.badge} onChange={e => updateSlide(index, 'badge', e.target.value)} className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-white outline-none focus:border-sajal-secondary text-sm font-medium transition-colors" />
                             </div>
                          </div>
                          
                          <div className="space-y-5">
                             <div>
                                <label className="block text-sm font-bold text-slate-600 mb-1">Short Description</label>
                                <textarea value={slide.description} onChange={e => updateSlide(index, 'description', e.target.value)} rows={3} className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-white outline-none focus:border-sajal-secondary text-sm font-medium transition-colors resize-none" />
                             </div>
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                               <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wide">Primary Button Text</label>
                                  <input type="text" value={slide.primaryCta} onChange={e => updateSlide(index, 'primaryCta', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:border-sajal-secondary text-sm" />
                               </div>
                               <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wide">Primary Button Link</label>
                                  <input type="text" value={slide.primaryHref} onChange={e => updateSlide(index, 'primaryHref', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:border-sajal-secondary text-sm mb-1" placeholder="#services or /request" />
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    <button type="button" onClick={() => updateSlide(index, 'primaryHref', '/services')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Services Page</button>
                                    <button type="button" onClick={() => updateSlide(index, 'primaryHref', '#services')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Our Services</button>
                                    <button type="button" onClick={() => updateSlide(index, 'primaryHref', '#contact')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Contact</button>
                                    <button type="button" onClick={() => updateSlide(index, 'primaryHref', 'tel:+91')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Phone</button>
                                  </div>
                               </div>
                               <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wide">Secondary Button Text</label>
                                  <input type="text" value={slide.secondaryCta} onChange={e => updateSlide(index, 'secondaryCta', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:border-sajal-secondary text-sm" />
                               </div>
                               <div>
                                  <label className="block text-xs font-bold text-slate-500 mb-1 uppercase tracking-wide">Secondary Button Link</label>
                                  <input type="text" value={slide.secondaryHref} onChange={e => updateSlide(index, 'secondaryHref', e.target.value)} className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white outline-none focus:border-sajal-secondary text-sm mb-1" placeholder="#contact" />
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    <button type="button" onClick={() => updateSlide(index, 'secondaryHref', '/services')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Services Page</button>
                                    <button type="button" onClick={() => updateSlide(index, 'secondaryHref', '#services')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Our Services</button>
                                    <button type="button" onClick={() => updateSlide(index, 'secondaryHref', '#contact')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Contact</button>
                                    <button type="button" onClick={() => updateSlide(index, 'secondaryHref', 'tel:+91')} className="text-[10px] bg-slate-100 hover:bg-slate-200 px-1.5 py-0.5 rounded text-slate-600 transition-colors">Phone</button>
                                  </div>
                               </div>
                             </div>
                          </div>
                       </div>
                    </div>
                 ))}
                 {slides.length === 0 && (
                   <div className="text-center py-12 text-slate-400 border-2 border-dashed border-slate-300 rounded-2xl bg-slate-50">
                     <ImageIcon className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                     <p className="font-medium text-slate-500">No banners added. Click "Add Banner" to create one.</p>
                   </div>
                 )}
              </div>
           </motion.section>
         )}

         {activeSubTab === 'store' as any && (
           <motion.section initial={{opacity:0, y:10}} animate={{opacity:1, y:0}} className="bg-slate-50 p-6 rounded-xl border border-slate-100 pb-12">
              <h4 className="font-bold text-lg mb-4 flex items-center gap-2"><Store className="w-5 h-5 text-sajal-secondary" /> Store Status Override</h4>
              <p className="text-sm text-slate-500 mb-6">Temporarily close the store. When closed, users will see a "Store Closed" popup but can still book appointments for future dates.</p>
              
              <div className="flex items-center gap-4 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                <div className="flex-1">
                  <h5 className="font-bold text-slate-800 mb-1">Close Store Today</h5>
                  <p className="text-sm text-slate-500 leading-snug">Toggle this to ON if you are closed for holidays or emergency.</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer scale-110">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={isStoreClosed}
                    onChange={(e) => setIsStoreClosed(e.target.checked)}
                  />
                  <div className="w-14 h-7 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-sajal-accent/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-red-500"></div>
                </label>
              </div>
           </motion.section>
         )}

         <div className="pt-8 mt-8 border-t border-slate-200 flex justify-end">
            <button onClick={saveSettings} disabled={saving} className="flex items-center justify-center gap-2 px-8 py-4 bg-sajal-primary text-white font-bold rounded-xl hover:bg-slate-800 w-full sm:w-auto shadow-lg hover:shadow-xl transition-all active:scale-95 disabled:opacity-50 text-lg">
              {saving ? 'Uploading & Saving...' : 'Save Site Settings'} <Save className="w-5 h-5" />
            </button>
         </div>
      </div>
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState<any[]>([]);
  
  useEffect(() => {
    const unsub = onValue(ref(db, 'users'), snap => {
       const data = snap.val();
       if(data) {
         setUsers(Object.keys(data).map(uid => ({ uid, ...data[uid] })));
       } else {
         setUsers([]);
       }
    });
    return () => unsub();
  }, []);

  const toggleAdmin = async (uid: string, currentRole: string) => {
    try {
      const { auth } = await import('../lib/firebase');
      if (auth.currentUser?.uid === uid) {
        toast.error("You cannot change your own admin access.");
        playSound('pop');
        return;
      }
      const newRole = currentRole === 'admin' ? 'user' : 'admin';
      await update(ref(db, `users/${uid}`), { role: newRole });
      toast.success(`User role updated to ${newRole}`);
      playSound('success');
    } catch (e: any) {
      console.error(e);
      toast.error('Failed to update user role');
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
      <h3 className="text-lg font-bold mb-6">User Management</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-slate-500">
              <th className="pb-3 font-semibold">Name</th>
              <th className="pb-3 font-semibold">Email</th>
              <th className="pb-3 font-semibold">Role</th>
              <th className="pb-3 font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.uid} className="border-b border-slate-100">
                <td className="py-4">
                  <div className="flex items-center gap-3">
                    {u.photoURL && <img src={u.photoURL} alt="" className="w-8 h-8 rounded-full" referrerPolicy="no-referrer" />}
                    <span className="font-medium">{u.name}</span>
                  </div>
                </td>
                <td className="py-4 text-slate-600">{u.email}</td>
                <td className="py-4">
                   <span className={`px-2 py-1 rounded-md text-xs font-bold ${u.role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'}`}>
                     {(u.role || 'user').toUpperCase()}
                   </span>
                </td>
                <td className="py-4">
                    <button onClick={() => toggleAdmin(u.uid, u.role)} className="text-sajal-secondary hover:text-sajal-primary font-semibold text-xs">
                       {u.role === 'admin' ? 'Remove Admin' : 'Make Admin'}
                    </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

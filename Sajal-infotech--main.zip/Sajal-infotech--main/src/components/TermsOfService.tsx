import React, { useEffect } from 'react';

export default function TermsOfService() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-32">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 md:p-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 mb-8 tracking-tight">Terms of Service</h1>
          <div className="prose prose-slate max-w-none prose-p:text-slate-600 prose-headings:text-slate-800">
            <p className="text-lg font-medium text-slate-500 mb-8">Last updated: {new Date().toLocaleDateString()}</p>
            
            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">1. Acceptance of Terms</h2>
              <p className="mb-4">By accessing and using Sajal Infotech's services, either online or physically at our Kadambagachi cyber cafe, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.</p>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">2. Description of Service</h2>
              <p className="mb-4">Sajal Infotech provides local internet services, documentation assistance (PAN/Aadhar, Passports, etc.), online form filling, flight and train ticket booking, money transfers, and other related services. The scope of these services is subject to change without notice.</p>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">3. User Responsibilities</h2>
              <p className="mb-4">When using our services, you agree that you will not use the service for any illegal purpose. You are responsible for ensuring the accuracy of all documentation, IDs, and details provided to us for processing applications or bookings.</p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Provide accurate and truthful information.</li>
                <li>Do not misuse our facilities or online portal for unauthorized access.</li>
                <li>Ensure compliance with local and national laws during use.</li>
              </ul>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">4. Payment and Fees</h2>
              <p className="mb-4">Fees for our services are specified at the time of the transaction. All fees are non-refundable unless otherwise explicitly stated or if the service could not be delivered due to an error on our part. Government fees for document generation are subject to change according to official guidelines.</p>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">5. Limitation of Liability</h2>
              <p className="mb-4">Sajal Infotech shall not be liable for any special or consequential damages that result from the use of, or the inability to use, the services and products offered, or the performance of the products. We just assist with applications and do not guarantee final document approval by government authorities.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">6. Contact Information</h2>
              <p className="mb-4">For any questions regarding these Terms of Service, please contact us:</p>
              <address className="not-italic text-slate-600 bg-slate-50 p-6 rounded-xl mt-4">
                <strong>Sajal Infotech</strong><br/>
                Kadambagachi, Kolkata<br/>
                Email: support@sajalinfotech.com<br/>
                Phone: +91 91234 56789
              </address>
            </section>
          </div>
        </div>
    </div>
  );
}

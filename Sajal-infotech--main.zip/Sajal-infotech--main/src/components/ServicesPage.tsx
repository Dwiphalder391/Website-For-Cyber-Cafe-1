import { Link, useNavigate } from 'react-router-dom';
import { servicesData } from '../servicesData';
import { FileText, Landmark, Ticket, Printer, Briefcase, Wifi, ArrowLeft, ArrowRight, Shield, Car, IdCard, Globe, Scale, MapIcon, GraduationCap, BookOpen, MousePointer2, Zap, Smartphone, Flame, Layers, Camera, Monitor } from 'lucide-react';
import * as motion from 'motion/react-client';
import { ReactNode, useMemo } from 'react';
import { useTranslation } from '../contexts/LanguageContext';

// Reusing icon map
const iconMap: Record<string, ReactNode> = {
  FileText: <FileText className="w-6 h-6" />,
  Landmark: <Landmark className="w-6 h-6" />,
  Ticket: <Ticket className="w-6 h-6" />,
  Printer: <Printer className="w-6 h-6" />,
  Briefcase: <Briefcase className="w-6 h-6" />,
  Wifi: <Wifi className="w-6 h-6" />,
  Shield: <Shield className="w-6 h-6" />,
  Car: <Car className="w-6 h-6" />,
  IdCard: <IdCard className="w-6 h-6" />,
  Globe: <Globe className="w-6 h-6" />,
  Scale: <Scale className="w-6 h-6" />,
  MapIcon: <MapIcon className="w-6 h-6" />,
  GraduationCap: <GraduationCap className="w-6 h-6" />,
  BookOpen: <BookOpen className="w-6 h-6" />,
  MousePointer2: <MousePointer2 className="w-6 h-6" />,
  Zap: <Zap className="w-6 h-6" />,
  Smartphone: <Smartphone className="w-6 h-6" />,
  Flame: <Flame className="w-6 h-6" />,
  Layers: <Layers className="w-6 h-6" />,
  Camera: <Camera className="w-6 h-6" />,
  Monitor: <Monitor className="w-6 h-6" />,
};

export default function ServicesPage() {
  const navigate = useNavigate();
  const { t } = useTranslation();

  return (
    <section className="pt-32 pb-24 bg-sajal-neutral2 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-12 text-center sm:text-left">
          <Link to="/" className="inline-flex items-center gap-2 text-sajal-accent hover:text-sajal-primary font-semibold mb-8 group transition-colors focus:outline-none">
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" /> {t("Back Home")}
          </Link>
          <span className="text-sajal-secondary font-bold tracking-wider uppercase text-xs sm:text-sm mb-3 block">
            {t("services.subtitle") || "Complete Toolkit"}
          </span>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-sajal-primary tracking-tight mb-6">
            {t("services.title")}
          </h1>
          <p className="text-sm sm:text-base md:text-lg text-sajal-text/80 leading-relaxed max-w-2xl">
            {t("services.desc") || "Browse through our full catalog of services. Click on any service to initiate a request or inquiry."}
          </p>
        </div>

        <div className="space-y-16 mt-10">
          {Object.entries(
            servicesData.reduce((acc, curr) => {
              const cat = curr.category || 'Other Services';
              if (!acc[cat]) acc[cat] = [];
              acc[cat].push(curr);
              return acc;
            }, {} as Record<string, typeof servicesData>)
          ).map(([category, items], categoryIdx) => (
            <div key={category} className="scroll-mt-24" id={category.replace(/\s+/g, '-').toLowerCase()}>
              <h2 className="text-2xl sm:text-3xl font-bold text-sajal-primary mb-8 border-b-2 border-sajal-secondary/20 pb-4 inline-block">
                {t(category)}
              </h2>
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
                {items.map((service, index) => (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                  >
                    <Link
                      to={`/request/${service.id}`}
                      className="bg-white p-4 sm:p-6 lg:p-8 rounded-2xl sm:rounded-3xl border border-slate-100 shadow-lg shadow-slate-200/40 hover:shadow-xl hover:shadow-sajal-accent/10 border-b-4 border-b-sajal-secondary hover:border-b-sajal-accent hover:-translate-y-1.5 transition-all duration-300 group flex flex-col h-full"
                    >
                      <div className="mb-4 sm:mb-6 h-10 w-10 sm:h-14 sm:w-14 rounded-xl sm:rounded-2xl flex items-center justify-center bg-sajal-neutral2 text-sajal-accent group-hover:bg-sajal-accent group-hover:text-white transition-colors duration-300 shadow-sm">
                        {iconMap[service.icon] || <FileText className="w-6 h-6" />}
                      </div>
                      <h3 className="text-sm sm:text-xl font-bold text-sajal-text mb-2 sm:mb-3 group-hover:text-sajal-accent transition-colors leading-tight line-clamp-2">
                        {t(service.title)}
                      </h3>
                      <p className="text-sajal-text/80 text-xs sm:text-sm leading-relaxed flex-grow">
                        {t(service.description)}
                      </p>
                      <div className="mt-4 flex items-center gap-1 text-xs font-bold text-sajal-secondary group-hover:text-sajal-accent transition-colors">
                        {t("Apply Now")} <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

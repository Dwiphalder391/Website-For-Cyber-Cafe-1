import React from 'react';
import * as motion from 'motion/react-client';
import { playSound } from '../lib/sounds';
import { useTranslation, LanguageCode } from '../contexts/LanguageContext';

interface LanguageSelectorProps {
  onSelect: (lang: string) => void;
}

export default function LanguageSelector({ onSelect }: LanguageSelectorProps) {
  const { setLanguage } = useTranslation();
  
  const languages = [
    { code: 'en', name: 'English', native: 'English', flag: '🇬🇧' },
    { code: 'hi', name: 'Hindi', native: 'हिन्दी', flag: '🇮🇳' },
    { code: 'bn', name: 'Bengali', native: 'বাংলা', flag: '🇮🇳' }
  ];

  const handleSelect = (code: string) => {
    playSound('pop');
    setLanguage(code as LanguageCode);
    onSelect(code);
  };

  return (
    <div className="fixed inset-0 bg-slate-900 z-[100] flex flex-col items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-white p-8 sm:p-12 rounded-[2rem] shadow-2xl max-w-md w-full text-center"
      >
        <div className="w-20 h-20 bg-sajal-neutral2 text-sajal-primary rounded-full flex items-center justify-center mx-auto mb-6">
           <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/><path d="M2 12h20"/></svg>
        </div>
        <h2 className="text-3xl font-bold text-slate-800 mb-2">Choose Language</h2>
        <p className="text-slate-500 mb-8 text-sm">Select your preferred language to continue</p>
        
        <div className="space-y-4">
          {languages.map((lang, i) => (
            <motion.button
              key={lang.code}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => handleSelect(lang.code)}
              className="w-full flex items-center justify-between p-4 rounded-xl border-2 border-slate-100 hover:border-sajal-secondary hover:bg-sajal-neutral2 transition-all group"
            >
              <div className="flex items-center gap-4">
                <span className="text-2xl">{lang.flag}</span>
                <span className="text-lg font-bold text-slate-700 group-hover:text-sajal-primary transition-colors">{lang.native}</span>
              </div>
              <span className="text-sm font-semibold text-slate-400 group-hover:text-sajal-secondary transition-colors">{lang.name}</span>
            </motion.button>
          ))}
        </div>
      </motion.div>
    </div>
  );
}

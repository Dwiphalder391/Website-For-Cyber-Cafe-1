import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { ref, onValue, push, set, serverTimestamp } from 'firebase/database';
import { MessageCircle, X, Send } from 'lucide-react';
import * as motion from 'motion/react-client';

export default function SupportWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;
    const chatRef = ref(db, `supportChats/${user.uid}/messages`);
    const unsub = onValue(chatRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        const msgs = Object.keys(data).map(key => ({
          id: key,
          ...data[key]
        })).sort((a, b) => a.timestamp - b.timestamp);
        setMessages(msgs);
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
      }
    });
    return () => unsub();
  }, [user]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user) return;

    const chatRef = ref(db, `supportChats/${user.uid}/messages`);
    const newMsgRef = push(chatRef);
    await set(newMsgRef, {
      text: newMessage,
      senderId: user.uid,
      senderName: user.displayName,
      timestamp: serverTimestamp(),
      isAdmin: false
    });
    
    // Update summary for admin panel
    const chatMetaRef = ref(db, `supportChats/${user.uid}/meta`);
    await set(chatMetaRef, {
      lastMessage: newMessage,
      lastTimestamp: serverTimestamp(),
      userName: user.displayName,
      userPhoto: user.photoURL,
      unreadCountAdmin: 1 // Trigger unread for admin
    });

    setNewMessage('');
  };

  if (!user) return null; // Only logged-in users can use support chat

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 p-4 bg-sajal-secondary text-white rounded-full shadow-xl shadow-sajal-secondary/30 hover:bg-sajal-primary transition-colors z-50 group hover:-translate-y-1"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {isOpen && (
        <motion.div
           initial={{ opacity: 0, y: 20, scale: 0.9 }}
           animate={{ opacity: 1, y: 0, scale: 1 }}
           className="fixed bottom-24 right-6 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl z-50 border border-slate-100 flex flex-col overflow-hidden"
           style={{ height: '500px', maxHeight: '70vh' }}
        >
          <div className="p-4 bg-sajal-primary text-white flex justify-between items-center">
            <div>
              <h3 className="font-bold">Support Chat</h3>
              <p className="text-xs text-white/80">We typically reply in a few minutes.</p>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white/80 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="flex-1 p-4 overflow-y-auto bg-slate-50 flex flex-col gap-3">
            {messages.map(msg => (
              <div key={msg.id} className={`flex ${msg.isAdmin ? 'justify-start' : 'justify-end'}`}>
                 <div className={`max-w-[80%] rounded-xl px-4 py-2 text-sm ${msg.isAdmin ? 'bg-white border text-sajal-text rounded-tl-none' : 'bg-sajal-secondary text-white rounded-tr-none'}`}>
                   {msg.text}
                 </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <form onSubmit={sendMessage} className="p-3 bg-white border-t border-slate-100 flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 bg-slate-100 rounded-xl px-4 py-2 outline-none text-sm focus:ring-2 focus:ring-sajal-accent/20"
            />
            <button type="submit" className="p-2 bg-sajal-secondary text-white rounded-xl hover:bg-sajal-primary transition-colors disabled:opacity-50" disabled={!newMessage.trim()}>
              <Send className="w-5 h-5" />
            </button>
          </form>
        </motion.div>
      )}
    </>
  );
}

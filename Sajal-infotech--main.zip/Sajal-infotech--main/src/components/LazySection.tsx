import React, { useState, useEffect, useRef, ReactNode, Suspense } from 'react';

interface LazySectionProps {
  children: ReactNode;
  placeholderHeight?: string;
  fallback?: ReactNode;
  id?: string;
}

export default function LazySection({ children, placeholderHeight = 'min-h-[50vh]', fallback = null, id }: LazySectionProps) {
  const [isVisible, setIsVisible] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            if (containerRef.current) {
              observer.unobserve(containerRef.current);
            }
          }
        });
      },
      {
        rootMargin: '200px 0px', // Load it when it's 200px from coming into view
      }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, []);

  return (
    <div ref={containerRef} id={id} className={!isVisible ? placeholderHeight : ''}>
      {isVisible ? (
        <Suspense fallback={fallback || <div className="flex justify-center items-center h-40"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sajal-primary"></div></div>}>
          {children}
        </Suspense>
      ) : (
        fallback || null
      )}
    </div>
  );
}

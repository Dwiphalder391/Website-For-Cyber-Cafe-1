import { FileText, Landmark, Ticket, Printer, Briefcase, Wifi, ArrowRight, Shield, Car, IdCard, Globe, Scale, MapIcon, GraduationCap, BookOpen, MousePointer2, Zap, Smartphone, Flame, Layers, Camera, Monitor } from 'lucide-react';
import { servicesData } from '../data';
import * as motion from 'motion/react-client';
import { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from '../contexts/LanguageContext';

const iconMap: Record<string, ReactNode> = {
  FileText: <FileText className="w-6 h-6" />,
  Landmark: <Landmark className="w-6 h-6" />,
  Ticket: <Ticket className="w-6 h-6" />,
  Printer: <Printer className="w-6 h-6" />,
  Briefcase: <Briefcase className="w-6 h-6" />,
  Wifi: <Wifi className="w-6 h-6" />,
  Shield: <Shield className="w-6 h-6" />,
  Car: <Car className="w-6 h-6" />,
  IdCard: <IdCard className="w-6 h-6" />,
  Globe: <Globe className="w-6 h-6" />,
  Scale: <Scale className="w-6 h-6" />,
  MapIcon: <MapIcon className="w-6 h-6" />,
  GraduationCap: <GraduationCap className="w-6 h-6" />,
  BookOpen: <BookOpen className="w-6 h-6" />,
  MousePointer2: <MousePointer2 className="w-6 h-6" />,
  Zap: <Zap className="w-6 h-6" />,
  Smartphone: <Smartphone className="w-6 h-6" />,
  Flame: <Flame className="w-6 h-6" />,
  Layers: <Layers className="w-6 h-6" />,
  Camera: <Camera className="w-6 h-6" />,
  Monitor: <Monitor className="w-6 h-6" />,
};

export default function Services() {
  const displayedServices = servicesData.slice(0, 6);
  const { t } = useTranslation();
  return (
    <section className="py-20 md:py-28 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 md:mb-20">
          <motion.span 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sajal-secondary font-bold tracking-wider uppercase text-xs sm:text-sm mb-3 block"
          >
            {t("services.subtitle")}
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-3xl sm:text-4xl md:text-5xl font-bold text-sajal-primary tracking-tight mb-6"
          >
            {t("services.title")}
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-sm sm:text-base md:text-lg text-sajal-text/80 leading-relaxed"
          >
            {t("services.desc")}
          </motion.p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-6 md:gap-8">
          {displayedServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1, type: "spring", bounce: 0.2 }}
            >
              <Link
                to={`/request/${service.id}`}
                className="bg-white p-4 sm:p-6 lg:p-8 rounded-2xl sm:rounded-3xl border border-slate-100 shadow-lg shadow-slate-200/40 hover:shadow-xl hover:shadow-sajal-accent/10 border-b-4 border-b-sajal-secondary hover:border-b-sajal-accent hover:-translate-y-1.5 transition-all duration-300 group flex flex-col h-full block"
              >
                <div className="mb-4 sm:mb-6 h-10 w-10 sm:h-14 sm:w-14 rounded-xl sm:rounded-2xl flex items-center justify-center bg-sajal-neutral2 text-sajal-accent group-hover:bg-sajal-accent group-hover:text-white transition-colors duration-300 shadow-sm">
                  {iconMap[service.icon]}
                </div>
                <h3 className="text-sm sm:text-xl font-bold text-sajal-text mb-2 sm:mb-3 group-hover:text-sajal-accent transition-colors leading-tight line-clamp-2">
                  {t(service.title)}
                </h3>
                <p className="text-sajal-text/80 text-xs sm:text-sm leading-relaxed flex-grow">
                  {t(service.description)}
                </p>
              </Link>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.3 }}
          className="mt-12 md:mt-16 text-center"
        >
          <Link 
            to="/services"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-sajal-primary text-white font-bold rounded-xl hover:bg-sajal-accent transition-colors shadow-lg shadow-sajal-primary/20 hover:shadow-sajal-accent/30 hover:-translate-y-1 group"
          >
            {t("services.view_all")}
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}

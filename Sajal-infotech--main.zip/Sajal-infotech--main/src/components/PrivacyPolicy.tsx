import React, { useEffect } from 'react';

export default function PrivacyPolicy() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-32">
        <div className="bg-white rounded-3xl shadow-sm border border-slate-200 p-8 md:p-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-slate-900 mb-8 tracking-tight">Privacy Policy</h1>
          <div className="prose prose-slate max-w-none prose-p:text-slate-600 prose-headings:text-slate-800">
            <p className="text-lg font-medium text-slate-500 mb-8">Last updated: {new Date().toLocaleDateString()}</p>
            
            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">1. Information We Collect</h2>
              <p className="mb-4">At Sajal Infotech, we collect information you provide directly to us when you use our services. This includes personal information such as your name, email address, phone number, and any other information you choose to provide when making an inquiry, booking a flight/train, or applying for documentation services.</p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Contact Information (Name, Email, Phone Number)</li>
                <li>Service specific details required for documentation or bookings</li>
                <li>Account credentials if you create an online account</li>
              </ul>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">2. How We Use Your Information</h2>
              <p className="mb-4">We use the information we collect to provide, maintain, and improve our services, including:</p>
              <ul className="list-disc pl-6 mb-4 space-y-2">
                <li>Processing your requests for documentation, tickets, and other services</li>
                <li>Communicating with you regarding your service requests</li>
                <li>Sending you confirmations, updates, and support messages</li>
                <li>Improving our local cyber cafe and online services</li>
              </ul>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">3. Information Sharing</h2>
              <p className="mb-4">We do not sell, trade, or rent your personal information to third parties. We may share your information only with trusted partners and government portals strictly for the purpose of fulfilling the services you requested (e.g., booking portals, documentation authorities).</p>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">4. Data Security</h2>
              <p className="mb-4">We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. However, no data transmission over the internet or storage system can be guaranteed to be 100% secure.</p>
            </section>

            <section className="mb-10">
              <h2 className="text-2xl font-bold mb-4">5. Your Rights</h2>
              <p className="mb-4">You have the right to request access to the personal information we hold about you, to request its correction, or its deletion. Contact us at support@sajalinfotech.com for any privacy-related requests.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold mb-4">6. Contact Us</h2>
              <p className="mb-4">If you have any questions about this Privacy Policy, please contact us at:</p>
              <address className="not-italic text-slate-600 bg-slate-50 p-6 rounded-xl mt-4">
                <strong>Sajal Infotech</strong><br/>
                Kadambagachi, Kolkata<br/>
                Email: support@sajalinfotech.com<br/>
                Phone: +91 91234 56789
              </address>
            </section>
          </div>
        </div>
    </div>
  );
}

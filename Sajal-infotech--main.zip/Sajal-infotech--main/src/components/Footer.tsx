import { Link } from "react-router-dom";
import { Globe, Facebook, Twitter, Instagram } from "lucide-react";
import { useSiteSettings } from "../hooks/useSiteSettings";
import { useTranslation } from "../contexts/LanguageContext";

export default function Footer() {
  const { settings } = useSiteSettings();
  const { t } = useTranslation();
  
  const logoUrl =
    settings?.logoUrl ||
    "https://storage.googleapis.com/aistudio-uploaded-blobs/Zz11c2Vycy82NDUyMTYwMTgzMDQvYmxvYnMvYXNzZXRfanlsdWxib3VlNWV5MTRxMQ.webp";

  return (
    <footer className="bg-sajal-primary border-t border-sajal-primary/80 text-sajal-neutral1">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-white p-2 rounded-xl shadow-lg shadow-sajal-secondary/20">
                <img
                  src={logoUrl}
                  alt="Sajal Infotech Logo"
                  className="h-6 w-6 object-contain"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">
                {t("Sajal Infotech")}
              </span>
            </div>
            <p className="text-sajal-neutral1/80 text-sm leading-relaxed max-w-sm mb-8">
              {t("Your trusted local partner for daily internet services, documentation, flight/train bookings, and high-speed internet browsing in Kadambagachi, Kolkata.")}
            </p>
            <div className="flex items-center gap-4 mt-8">
              <a
                href="#"
                className="h-10 w-10 flex items-center justify-center rounded-full bg-sajal-primary/50 border border-sajal-secondary/30 hover:bg-sajal-secondary text-white transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="h-10 w-10 flex items-center justify-center rounded-full bg-sajal-primary/50 border border-sajal-secondary/30 hover:bg-sajal-secondary text-white transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="#"
                className="h-10 w-10 flex items-center justify-center rounded-full bg-sajal-primary/50 border border-sajal-secondary/30 hover:bg-sajal-secondary text-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg tracking-wide whitespace-nowrap">
              {t("Quick Links")}
            </h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="#home"
                  className="text-sm text-sajal-neutral1/80 hover:text-sajal-secondary transition-colors font-medium whitespace-nowrap"
                >
                  {t("nav.home")}
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="text-sm text-sajal-neutral1/80 hover:text-sajal-secondary transition-colors font-medium whitespace-nowrap"
                >
                  {t("nav.services")}
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="text-sm text-sajal-neutral1/80 hover:text-sajal-secondary transition-colors font-medium whitespace-nowrap"
                >
                  {t("nav.contact")}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 text-lg tracking-wide whitespace-nowrap">
              {t("Contact Us")}
            </h4>
            <ul className="space-y-5">
              <li className="text-sm text-sajal-neutral1/80 flex flex-col">
                <span className="text-xs uppercase tracking-wider font-bold text-sajal-neutral1/50 mb-1">
                  {t("Phone")}
                </span>
                <span className="text-white font-medium">+91 91234 56789</span>
              </li>
              <li className="text-sm text-sajal-neutral1/80 flex flex-col pt-1">
                <span className="text-xs uppercase tracking-wider font-bold text-sajal-neutral1/50 mb-1">
                  {t("Email")}
                </span>
                <span className="text-white font-medium">
                  support@sajalinfotech.com
                </span>
              </li>
              <li className="text-sm text-sajal-neutral1/80 flex flex-col pt-4 border-t border-sajal-neutral1/10 mt-2">
                <a
                  href="https://www.justdial.com/Kolkata/Sajal-Infotech-Kadambagachi/033PXX33-XX33-220618102709-I5L4_BZDET/reviews"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center text-sajal-secondary hover:text-sajal-neutral2 transition-colors font-semibold"
                >
                  {t("View our Justdial Reviews")} →
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-sajal-neutral1/10 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-center md:text-left">
          <p className="text-sajal-neutral1/50 text-[13px] font-medium">
            © {new Date().getFullYear()} Sajal Infotech. {t("All rights reserved.")}
          </p>
          <div className="flex flex-wrap justify-center gap-4 md:gap-6 mt-4 md:mt-0">
            <Link
              to="/privacy-policy"
              className="text-[13px] font-medium text-sajal-neutral1/80 hover:text-sajal-secondary whitespace-nowrap transition-colors"
            >
              {t("Privacy Policy")}
            </Link>
            <Link
              to="/terms-of-service"
              className="text-[13px] font-medium text-sajal-neutral1/80 hover:text-sajal-secondary whitespace-nowrap transition-colors"
            >
              {t("Terms of Service")}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useEffect, useState, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import * as motion from 'motion/react-client';
import { useTranslation } from '../contexts/LanguageContext';
import { AlertTriangle, X, Check } from 'lucide-react';

export default function BackButtonHandler() {
  const [showExitModal, setShowExitModal] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useTranslation();
  const setupDone = useRef(false);

  useEffect(() => {
    // Only setup the trap once when the app loads
    if (!setupDone.current) {
      const currentState = window.history.state || {};
      if (!currentState.isBase) {
        // Tag the initial history entry as the base
        window.history.replaceState({ ...currentState, isBase: true }, '');
        // Push a new entry on top, so when they press back they hit the base
        window.history.pushState({ ...currentState, isApp: true }, '');
      }
      setupDone.current = true;
    }
  }, []);

  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      const state = event.state || {};

      // If we fall backward into the "base" state, the user is trying to exit to OS / browser level
      if (state.isBase) {
        // First, immediately push a state to trap them again
        window.history.pushState({ isApp: true }, '', window.location.pathname);

        // Then decide what to do
        const currentPath = window.location.pathname;

        if (currentPath === '/') {
          // If they were on the home page, ask for confirmation to exit
          setShowExitModal(true);
        } else {
          // If they were anywhere else, intercept the back and send them safely to home
          navigate('/', { replace: true });
        }
      } else {
        // Regular back navigation within the app
        setShowExitModal(false);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [navigate]);

  const handleConfirmExit = () => {
    setShowExitModal(false);
    // Best effort cross-platform close approach
    window.open('about:blank', '_self');
    window.close();
  };

  const handleCancelExit = () => {
    setShowExitModal(false);
  };

  if (!showExitModal) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-white rounded-[2rem] p-8 max-w-sm w-full shadow-2xl relative text-center border-2 border-sajal-accent/20"
      >
        <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
          <AlertTriangle className="w-8 h-8" />
        </div>

        <h2 className="text-xl font-bold text-slate-800 mb-2">
          {t("Exit Application") || "Exit Application"}
        </h2>
        
        <p className="text-slate-600 font-medium mb-8 leading-relaxed">
          {t("Are you sure you want to exit the application?") || "Are you sure you want to exit the application?"}
        </p>

        <div className="flex gap-4">
          <button
            onClick={handleCancelExit}
            className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <X className="w-4 h-4" /> {t("No") || "No"}
          </button>
          <button
            onClick={handleConfirmExit}
            className="flex-1 py-3 bg-red-500 hover:bg-red-600 text-white font-bold rounded-xl transition-colors shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
          >
            <Check className="w-4 h-4" /> {t("Yes") || "Yes"}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

import { X, Store } from 'lucide-react';
import * as motion from 'motion/react-client';
import { useTranslation } from '../contexts/LanguageContext';
import { useSiteSettings } from '../hooks/useSiteSettings';
import { useState, useEffect } from 'react';

export default function StoreClosedModal() {
  const { t } = useTranslation();
  const { settings } = useSiteSettings();
  const [isVisible, setIsVisible] = useState(false);
  const [hasDismissed, setHasDismissed] = useState(false);

  useEffect(() => {
    if (settings?.isStoreClosed && !hasDismissed) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  }, [settings?.isStoreClosed, hasDismissed]);

  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm"
    >
      <motion.div
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-white rounded-[2rem] p-8 max-w-md w-full shadow-2xl relative text-center border-2 border-sajal-accent/20"
      >
        <button
          onClick={() => {
            setIsVisible(false);
            setHasDismissed(true);
          }}
          className="absolute top-4 right-4 p-2 bg-slate-100 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="w-20 h-20 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
          <Store className="w-10 h-10" />
        </div>

        <h2 className="text-2xl font-bold text-slate-800 mb-3 tracking-tight">
          {t("Today Store is Off") || "Today Store is Off"}
        </h2>
        
        <p className="text-slate-600 font-medium mb-8 leading-relaxed">
          {t("Sorry, our cyber cafe is closed today. You can still submit requests for future dates, and we will process them when we open.") || "Sorry, our cyber cafe is closed today. You can still submit requests for future dates, and we will process them when we open."}
        </p>

        <button
          onClick={() => {
            setIsVisible(false);
            setHasDismissed(true);
          }}
          className="w-full py-4 bg-sajal-secondary hover:bg-sajal-primary text-white font-bold rounded-xl transition-colors shadow-lg shadow-sajal-secondary/20"
        >
          {t("Continue to Website") || "Continue to Website"}
        </button>
      </motion.div>
    </motion.div>
  );
}

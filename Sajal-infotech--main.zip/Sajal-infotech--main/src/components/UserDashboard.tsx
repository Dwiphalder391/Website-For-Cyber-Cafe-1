import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db } from '../lib/firebase';
import { ref, onValue } from 'firebase/database';
import { FileText, Clock, CheckCircle, XCircle } from 'lucide-react';
import * as motion from 'motion/react-client';
import { Navigate } from 'react-router-dom';

export default function UserDashboard() {
  const { user } = useAuth();
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const reqRef = ref(db, 'requests');
    const unsub = onValue(reqRef, (snapshot) => {
      const data = snapshot.val();
      if (data) {
        // Filter requests by the current user's ID
        const arr = Object.keys(data)
          .map(key => ({ id: key, ...data[key] }))
          .filter(req => req.userId === user.uid)
          .sort((a, b) => b.timestamp - a.timestamp);
        setRequests(arr);
      } else {
        setRequests([]);
      }
      setLoading(false);
    });

    return () => unsub();
  }, [user]);

  if (!user) {
    return <Navigate to="/" />;
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'rejected': return <XCircle className="w-5 h-5 text-red-500" />;
      default: return <Clock className="w-5 h-5 text-amber-500" />;
    }
  };

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'rejected': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-amber-100 text-amber-800 border-amber-200';
    }
  };

  return (
    <div className="min-h-screen pt-32 pb-24 bg-sajal-neutral2">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="mb-10 text-center sm:text-left">
          <h1 className="text-3xl sm:text-4xl font-bold text-sajal-primary tracking-tight">My Setup Applications</h1>
          <p className="mt-4 text-slate-600 max-w-2xl text-lg">View the status of your service requests and applications.</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sajal-secondary"></div>
          </div>
        ) : requests.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-12 text-center">
            <div className="w-16 h-16 bg-slate-50 text-slate-300 rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">No Applications Found</h3>
            <p className="text-slate-500">You haven't submitted any service requests yet.</p>
          </div>
        ) : (
          <div className="space-y-6">
            {requests.map((req, i) => (
              <motion.div
                key={req.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden"
              >
                <div className="p-4 sm:p-6 sm:flex flex-row justify-between items-start gap-4">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-2">
                       <h3 className="text-xl font-bold text-sajal-primary">{req.serviceName || 'General Inquiry'}</h3>
                       <span className={`px-2.5 py-1 rounded-full text-xs font-bold border uppercase tracking-wider flex items-center gap-1.5 ${getStatusStyle(req.status)}`}>
                         {getStatusIcon(req.status)} {req.status || 'Pending'}
                       </span>
                    </div>
                    <div className="text-xs text-slate-400 font-medium tracking-wide font-mono mb-4">
                      ID: {req.id} • {new Date(req.timestamp).toLocaleString()}
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 text-sm text-slate-700 mb-4">
                      <strong>Your Message:</strong>
                      <p className="mt-1 whitespace-pre-wrap">{req.message}</p>
                    </div>

                    {req.adminReply && (
                      <div className="bg-sajal-neutral2 p-4 rounded-xl border border-sajal-neutral1 relative">
                        <div className="absolute top-0 left-0 w-1 h-full bg-sajal-secondary rounded-l-xl"></div>
                        <strong>Admin Response:</strong>
                        <p className="mt-1 text-slate-800 whitespace-pre-wrap">{req.adminReply}</p>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

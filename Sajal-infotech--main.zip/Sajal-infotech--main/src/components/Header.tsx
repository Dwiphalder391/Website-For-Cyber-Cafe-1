import { Monitor, Menu, X, Phone, MapPin, Mail, Globe, LogIn, LogOut, ShieldCheck, FileText, ChevronDown, UserCircle } from 'lucide-react';
import React, { useState, useEffect } from 'react';
import * as motion from 'motion/react-client';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useSiteSettings } from '../hooks/useSiteSettings';
import { useTranslation, LanguageCode } from '../contexts/LanguageContext';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, isAdmin, signInWithGoogle, logout } = useAuth();
  const { settings } = useSiteSettings();
  const { t, language, setLanguage } = useTranslation();

  const logoUrl = settings?.logoUrl || "https://storage.googleapis.com/aistudio-uploaded-blobs/Zz11c2Vycy82NDUyMTYwMTgzMDQvYmxvYnMvYXNzZXRfanlsdWxib3VlNWV5MTRxMQ.webp";

  useEffect(() => {
    let prevScrollY = window.scrollY;
    let accumulatedUpScroll = 0;

    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Update scrolled state for styling
      setIsScrolled(currentScrollY > 20);

      // Hide header on scroll down, show on scroll up with a threshold
      if (currentScrollY > prevScrollY) {
        // Scrolling down
        accumulatedUpScroll = 0;
        if (currentScrollY > 100) {
          setIsVisible(false);
        }
      } else if (currentScrollY < prevScrollY) {
        // Scrolling up
        accumulatedUpScroll += (prevScrollY - currentScrollY);
        if (accumulatedUpScroll > 80 || currentScrollY < 20) {
          setIsVisible(true);
        }
      }
      
      prevScrollY = currentScrollY;
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLogout = () => {
    const message = language === 'bn' ? 'আপনি কি নিশ্চিত যে আপনি লগআউট করতে চান?' 
                  : language === 'hi' ? 'क्या आप वाकई लॉगआउट करना चाहते हैं?'
                  : 'Are you sure you want to logout?';
    if (window.confirm(message)) {
      logout();
      setIsMenuOpen(false);
    }
  };

  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const navLinks = [
    { name: t('nav.home'), href: '/' },
    { name: t('nav.services'), href: '/services' },
    { name: t('nav.contact'), href: '/#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    setIsMenuOpen(false);
    if (href.startsWith('/#')) {
      const targetId = href.replace('/#', '');
      if (location.pathname === '/') {
         e.preventDefault();
         const element = document.getElementById(targetId);
         if (element) {
            const top = element.getBoundingClientRect().top + window.scrollY;
            window.scrollTo({
                top: top - 110, // Adjust for fixed header
                behavior: 'smooth'
            });
         }
      }
    }
  };

  // Close profile dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.profile-dropdown-container')) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 flex flex-col font-sans transition-transform duration-300 ease-in-out ${isVisible ? 'translate-y-0' : '-translate-y-full'}`}>
      {/* Top Announcement Banner */}
      <div className="bg-sajal-primary text-sajal-neutral2 py-1.5 px-4 sm:px-6 lg:px-8 text-xs font-medium hidden md:flex justify-between items-center transition-all">
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-2 hover:text-white transition-colors cursor-pointer"><MapPin className="h-3.5 w-3.5 text-sajal-secondary" /> Kadambagachi, West Bengal</span>
          <span className="flex items-center gap-2 hover:text-white transition-colors cursor-pointer"><Mail className="h-3.5 w-3.5 text-sajal-secondary" /> support@sajalinfotech.com</span>
        </div>
        <div className="flex items-center gap-4 text-white font-semibold">
          <span className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-sajal-secondary" /> +91 91234 56789</span>
          
          <select 
             value={language} 
             onChange={(e) => setLanguage(e.target.value as LanguageCode)} 
             className="bg-white/10 text-white text-xs border border-white/20 rounded px-1.5 py-0.5 outline-none cursor-pointer"
          >
             <option value="en" className="text-black">English</option>
             <option value="hi" className="text-black">हिन्दी</option>
             <option value="bn" className="text-black">বাংলা</option>
          </select>
        </div>
      </div>

      {/* Main Navbar */}
      <div className={`bg-white/95 backdrop-blur-md border-b border-sajal-neutral1 transition-all duration-300 ${isScrolled ? 'py-1.5 shadow-md' : 'py-3 shadow-sm'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 transition-all">
          <div className="flex justify-between items-center">
            <Link to="/" className="flex items-center gap-3">
              <div className="bg-white p-2 rounded-xl shadow-lg shadow-sajal-primary/10 border border-sajal-neutral1">
                <img src={logoUrl} alt="Sajal Infotech Logo" className="h-7 w-7 sm:h-8 sm:w-8 object-contain" referrerPolicy="no-referrer" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl sm:text-2xl font-bold text-sajal-primary tracking-tight leading-none mb-1">Sajal Infotech</span>
                <span className="text-[10px] sm:text-xs font-bold text-sajal-secondary uppercase tracking-widest leading-none">Cyber Cafe Services</span>
              </div>
            </Link>
            
            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center gap-4 xl:gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="text-[13px] lg:text-sm font-semibold text-sajal-text hover:text-sajal-secondary transition-colors whitespace-nowrap"
                >
                  {link.name}
                </Link>
              ))}
              
              {user ? (
                <div className="relative profile-dropdown-container">
                  <button
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center gap-2 p-1 pr-3 rounded-full border border-slate-200 hover:border-sajal-secondary hover:shadow-sm transition-all bg-white"
                  >
                    {user.photoURL ? (
                      <img src={user.photoURL} alt={user.name || "Profile"} className="w-8 h-8 rounded-full border border-slate-100 object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <UserCircle className="w-8 h-8 text-slate-400 m-0.5" />
                    )}
                    <span className="text-sm font-bold text-slate-700 max-w-[100px] truncate">{user.name || "Profile"}</span>
                    <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform ${isProfileOpen ? 'rotate-180' : ''}`} />
                  </button>
                  
                  {/* Dropdown Menu */}
                  {isProfileOpen && (
                    <div className="absolute right-0 top-full mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-100 overflow-hidden z-50">
                      <div className="p-4 bg-slate-50 border-b border-slate-100 flex flex-col items-center">
                        {user.photoURL ? (
                          <img src={user.photoURL} alt={user.name || "Profile"} className="w-14 h-14 rounded-full border-2 border-white shadow-sm mb-2 object-cover" referrerPolicy="no-referrer" />
                        ) : (
                          <UserCircle className="w-14 h-14 text-slate-400 mb-2" />
                        )}
                        <span className="text-sm font-bold text-slate-800 text-center w-full truncate">{user.name}</span>
                        <span className="text-xs font-medium text-slate-500 text-center w-full truncate mt-0.5">{user.email}</span>
                      </div>
                      
                      <div className="p-2 flex flex-col gap-1">
                        <Link 
                          to="/dashboard" 
                          onClick={() => setIsProfileOpen(false)}
                          className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-slate-700 hover:text-sajal-secondary hover:bg-slate-50 rounded-lg transition-colors"
                        >
                          <FileText className="w-4 h-4" /> My Applications
                        </Link>
                        
                        {isAdmin && (
                          <Link 
                            to="/admin" 
                            onClick={() => setIsProfileOpen(false)}
                            className="flex items-center gap-3 px-3 py-2 text-sm font-medium text-amber-600 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition-colors"
                          >
                            <ShieldCheck className="w-4 h-4" /> Admin Panel
                          </Link>
                        )}
                      </div>
                      
                      <div className="p-2 border-t border-slate-100">
                        <button
                          onClick={() => {
                            handleLogout();
                            setIsProfileOpen(false);
                          }}
                          className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm font-bold text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <LogOut className="w-4 h-4" /> Sign Out
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => signInWithGoogle().catch((e: any) => { if(e?.code !== 'auth/popup-closed-by-user') console.error(e); })}
                  className="font-bold text-sm flex items-center gap-2 px-4 py-2 border-2 border-sajal-secondary text-sajal-secondary rounded-lg hover:bg-sajal-secondary hover:text-white transition-colors"
                >
                  <LogIn className="w-4 h-4" /> {t('nav.login')}
                </button>
              )}

              <Link
                to="/request"
                className="px-6 py-2.5 text-sm font-bold text-white bg-sajal-secondary rounded-lg shadow-md hover:bg-sajal-primary hover:shadow-lg hover:shadow-sajal-secondary/30 transition-all active:scale-95"
              >
                {t('nav.support')}
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2.5 text-sajal-primary bg-sajal-neutral2 rounded-lg hover:bg-sajal-neutral1 transition-colors"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        <motion.div 
          initial={false}
          animate={{ height: isMenuOpen ? 'auto' : 0, opacity: isMenuOpen ? 1 : 0 }}
          className="md:hidden overflow-hidden bg-white border-t border-sajal-neutral1 shadow-inner"
        >
          <div className="px-4 pt-4 pb-6 space-y-2">
            
            {/* Mobile Language Switcher */}
            <div className="flex justify-between items-center px-5 py-3 mb-2 bg-slate-50 rounded-xl border border-slate-100">
               <span className="text-sm font-bold text-slate-500">Language</span>
               <select 
                 value={language} 
                 onChange={(e) => setLanguage(e.target.value as LanguageCode)} 
                 className="bg-white text-sajal-primary text-sm font-bold border border-slate-200 rounded-lg px-2 py-1 outline-none"
               >
                 <option value="en">English</option>
                 <option value="hi">हिन्दी</option>
                 <option value="bn">বাংলা</option>
               </select>
            </div>

            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className="block text-[15px] font-bold text-sajal-text hover:text-sajal-secondary hover:bg-sajal-neutral2 px-5 py-3 rounded-xl transition-all"
                onClick={(e) => handleNavClick(e, link.href)}
              >
                {link.name}
              </Link>
            ))}
            
            {user ? (
               <div className="pt-2 mt-2 border-t border-slate-100">
                 <div className="flex items-center gap-3 px-5 py-3 mb-2 bg-slate-50 rounded-xl">
                    {user.photoURL ? (
                      <img src={user.photoURL} alt={user.name || "Profile"} className="w-10 h-10 rounded-full border border-slate-200 object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <UserCircle className="w-10 h-10 text-slate-400" />
                    )}
                    <div className="flex flex-col">
                      <span className="text-[15px] font-bold text-slate-800">{user.name || "My Account"}</span>
                      <span className="text-xs font-medium text-slate-500">{user.email}</span>
                    </div>
                 </div>
                 
                 <Link
                   to="/dashboard"
                   className="flex items-center gap-2 text-[15px] font-bold text-sajal-secondary hover:text-sajal-primary hover:bg-sajal-neutral2 px-5 py-3 rounded-xl transition-all"
                   onClick={() => setIsMenuOpen(false)}
                 >
                   <FileText className="w-5 h-5" /> {t('nav.my_apps')}
                 </Link>
                 
                 {isAdmin && (
                   <Link
                     to="/admin"
                     className="flex items-center gap-2 text-[15px] font-bold text-amber-600 hover:text-amber-700 bg-amber-50 px-5 py-3 rounded-xl transition-all"
                     onClick={() => setIsMenuOpen(false)}
                   >
                     <ShieldCheck className="w-5 h-5" /> {t('nav.admin')}
                   </Link>
                 )}
                 
                 <button
                   onClick={(e) => { handleLogout(); setIsMenuOpen(false); }}
                   className="w-full flex items-center gap-2 text-[15px] font-bold text-red-500 hover:text-red-700 hover:bg-red-50 px-5 py-3 rounded-xl transition-all mt-1"
                 >
                   <LogOut className="w-5 h-5" /> {t('nav.logout')}
                 </button>
               </div>
            ) : (
               <button
                 onClick={() => { signInWithGoogle().catch((e: any) => { if(e?.code !== 'auth/popup-closed-by-user') console.error(e); }); setIsMenuOpen(false); }}
                 className="w-full flex items-center gap-2 text-[15px] font-bold text-sajal-secondary hover:text-sajal-primary border border-sajal-secondary hover:bg-sajal-neutral2 px-5 py-3 rounded-xl transition-all mt-3"
               >
                 <LogIn className="w-5 h-5" /> {t('nav.login')}
               </button>
            )}

            <Link
              to="/request"
              className="block w-full text-center px-4 py-3.5 mt-4 text-[15px] font-bold text-white bg-sajal-secondary rounded-xl hover:bg-sajal-primary transition-colors shadow-md"
              onClick={() => setIsMenuOpen(false)}
            >
              {t('nav.support')}
            </Link>
          </div>
        </motion.div>
      </div>
    </header>
  );
}

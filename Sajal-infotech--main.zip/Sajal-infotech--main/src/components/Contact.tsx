import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import * as motion from 'motion/react-client';
import { Link } from 'react-router-dom';

export default function Contact() {
  return (
    <section className="py-20 md:py-28 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-16 md:mb-20">
          <span className="text-sajal-secondary font-bold tracking-wider uppercase text-sm mb-3 block">Get Connected</span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-sajal-primary tracking-tight mb-4">
            Reach Out to Us
          </h2>
          <p className="text-base sm:text-lg text-sajal-text/80">
            Need help with an online form, Aadhaar update, or need high-speed internet? Drop by our store or send us a message.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-12 lg:gap-8 items-start">
          
          <div className="lg:col-span-2 p-6 rounded-3xl border-2 border-sajal-neutral1 bg-white shadow-sm space-y-6 sm:space-y-8">
            <motion.a 
              href="https://maps.app.goo.gl/5un63zi173fo1wcV6?g_st=ac"
              target="_blank"
              rel="noopener noreferrer"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex items-start gap-5 p-6 rounded-2xl bg-sajal-neutral2 border border-slate-100/50 hover:border-sajal-secondary transition-colors cursor-pointer shadow-sm hover:shadow-md"
            >
              <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center shrink-0 border border-slate-100 text-sajal-accent">
                <MapPin className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-sajal-primary mb-1">Store Location</h4>
                <p className="text-sm text-sajal-text leading-relaxed">Sajal Infotech, Kadambagachi,<br />Barasat Rd, Kolkata, WB 700125</p>
              </div>
            </motion.a>

            <motion.a 
              href="tel:+919123456789"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="flex items-start gap-5 p-6 rounded-3xl bg-sajal-neutral2 border border-slate-100/50 hover:border-sajal-secondary transition-colors cursor-pointer shadow-sm hover:shadow-md"
            >
              <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center shrink-0 border border-slate-100 text-sajal-secondary">
                <Phone className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-sajal-primary mb-1">Direct Line</h4>
                <p className="text-sm font-medium text-sajal-text">+91 91234 56789</p>
              </div>
            </motion.a>

            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="flex items-start gap-5 p-6 rounded-3xl bg-sajal-neutral2 border border-slate-100/50 hover:border-sajal-secondary transition-colors shadow-sm hover:shadow-md"
            >
              <div className="w-12 h-12 rounded-2xl bg-white shadow-sm flex items-center justify-center shrink-0 border border-slate-100 text-amber-600">
                <Clock className="h-6 w-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-sajal-primary mb-1">Working Hours</h4>
                <p className="text-sm text-sajal-text">Mon - Sat: 10:00 AM — 10:00 PM<br />Sunday: Closed</p>
              </div>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-3 bg-white p-6 sm:p-10 rounded-[2rem] shadow-xl shadow-sajal-neutral1/50 border border-sajal-neutral2"
          >
            <h3 className="text-2xl font-bold text-sajal-primary mb-8 w-full">Send a Service Request</h3>
            <div className="space-y-6">
              <p className="text-sajal-text/80 leading-relaxed mb-8">
                 Ready to apply for an online form or book a service? We have a dedicated request portal that allows you to easily track your application status.
              </p>
              <Link 
                to="/request"
                className="w-full py-4 px-6 bg-sajal-secondary text-white text-base font-bold rounded-xl hover:bg-sajal-primary hover:shadow-lg hover:shadow-sajal-secondary/25 transition-all outline-none focus:ring-4 focus:ring-sajal-secondary/20 active:scale-[0.98] flex items-center justify-center gap-2"
              >
                Go to Service Portal <Send className="w-5 h-5" />
              </Link>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
}

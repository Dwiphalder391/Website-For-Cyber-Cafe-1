import { useParams, Link, useNavigate } from 'react-router-dom';
import { servicesData } from '../servicesData';
import { ArrowLeft, Send, Phone, MessageCircle, Calendar, Clock } from 'lucide-react';
import * as motion from 'motion/react-client';
import React, { useState, useEffect } from 'react';
import { ref, push, serverTimestamp, query, orderByChild, equalTo, get } from 'firebase/database';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import { playSound } from '../lib/sounds';
import { useTranslation } from '../contexts/LanguageContext';

const TIME_SLOTS = [
  "10:00 AM - 12:00 PM",
  "12:00 PM - 02:00 PM",
  "04:00 PM - 06:00 PM",
  "06:00 PM - 08:00 PM",
  "08:00 PM - 10:00 PM"
];

export default function ServiceRequestPage() {
  const { serviceId } = useParams();
  const navigate = useNavigate();
  const { user, signInWithGoogle } = useAuth();
  const { t } = useTranslation();
  const service = servicesData.find(s => s.id === serviceId);
  const [showContact, setShowContact] = useState(false);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', message: service ? `I would like to apply/inquire about ${t(service.title)}. ` : '' });
  const [appointmentDate, setAppointmentDate] = useState<string>('');
  const [appointmentTime, setAppointmentTime] = useState<string>('');
  const [slotCounts, setSlotCounts] = useState<Record<string, number>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // If no specific service is selected, show general
  const title = service ? t(service.title) : t('General Service Inquiry');
  const description = service 
    ? t(service.description) 
    : t('Let us know how we can help you with our cyber cafe services.');

  // Validate dates: minimum 'today'
  const today = new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (!appointmentDate) {
      setSlotCounts({});
      return;
    }
    
    const checkSlots = async () => {
      try {
        const requestsRef = ref(db, 'requests');
        const q = query(requestsRef, orderByChild('appointmentDate'), equalTo(appointmentDate));
        const snapshot = await get(q);
        
        const counts: Record<string, number> = {};
        if (snapshot.exists()) {
          snapshot.forEach((childSnap) => {
            const data = childSnap.val();
            if (data.appointmentTime) {
              counts[data.appointmentTime] = (counts[data.appointmentTime] || 0) + 1;
            }
          });
        }
        setSlotCounts(counts);
        
        // Deselect if current time is full
        if (appointmentTime && counts[appointmentTime] >= 5) {
          setAppointmentTime('');
          toast.error(t("Selected time slot is now full. Please select another time.") || "Selected time slot is now full. Please select another time.");
        }
      } catch (err) {
        console.error("Error fetching slots", err);
      }
    };
    
    checkSlots();
  }, [appointmentDate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!appointmentDate || !appointmentTime) {
       toast.error(t("Please select an appointment date and time.") || "Please select an appointment date and time.");
       playSound('pop');
       return;
    }

    // Double check capacity locally before submit
    if (slotCounts[appointmentTime] >= 5) {
       toast.error(t("This slot is full. Please choose another one.") || "This slot is full. Please choose another one.");
       playSound('pop');
       return;
    }

    // Validate phone number (exactly 10 digits)
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(formData.phone)) {
       toast.error(t("Please enter a valid 10-digit phone number.") || "Please enter a valid 10-digit phone number.");
       playSound('pop');
       return;
    }

    setIsSubmitting(true);
    try {
      let currentUser = user;
      if (!currentUser) {
        // Not logged in, force login
        toast("Please login to submit a request. Your data will be saved.", { icon: '🔒' });
        await signInWithGoogle();
        
        // After signInWithGoogle resolves, wait a moment for auth state to update, or use auth.currentUser
        const { auth } = await import('../lib/firebase');
        currentUser = auth.currentUser as any;
        if (!currentUser) {
           throw new Error("Login failed or cancelled.");
        }
      }

      const dbRef = ref(db, 'requests');
      await push(dbRef, {
        ...formData,
        appointmentDate,
        appointmentTime,
        serviceId: serviceId || 'general',
        serviceName: title,
        timestamp: serverTimestamp(),
        status: 'pending',
        userId: currentUser.uid
      });
      playSound('success');
      toast.success(t("form.success") || "Request sent successfully!", {
        style: { background: '#10b981', color: '#fff' },
        iconTheme: { primary: '#fff', secondary: '#10b981' },
      });
      setFormData({ name: '', phone: '', email: '', message: '' });
      setAppointmentDate('');
      setAppointmentTime('');
      navigate('/dashboard');
    } catch (err: any) {
      console.error(err);
      if (err.message === "Login failed or cancelled.") {
         toast.error(err.message);
      } else if (err?.code === 'auth/popup-closed-by-user') {
         toast.error("Login cancelled. Request not submitted.");
      } else {
         toast.error("Error submitting request. Please try again.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="pt-32 pb-24 min-h-screen bg-sajal-neutral2 flex flex-col justify-center items-center">
      <div className="w-full max-w-3xl mx-auto px-4 sm:px-6">
        
        <Link to={serviceId ? "/services" : "/"} className="inline-flex items-center gap-2 text-sajal-accent hover:text-sajal-primary font-semibold mb-8 group transition-colors focus:outline-none">
          <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" /> Back
        </Link>
        
        <motion.div
           initial={{ opacity: 0, y: 20 }}
           animate={{ opacity: 1, y: 0 }}
           className="bg-white p-8 sm:p-12 rounded-[2rem] shadow-xl shadow-sajal-neutral1/50 border border-sajal-neutral1"
        >
          <div className="mb-10 text-center sm:text-left border-b border-sajal-neutral1/50 pb-8">
            <span className="text-sajal-secondary font-bold tracking-wider uppercase text-sm mb-3 block">Service Request</span>
            <h1 className="text-3xl sm:text-4xl font-bold text-sajal-primary tracking-tight mb-4">
              {title}
            </h1>
            <p className="text-sajal-text/80 text-base sm:text-lg">
              {description}
            </p>
          </div>

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-bold text-sajal-text mb-2">{t("form.name")} *</label>
                <input 
                  type="text" 
                  id="name" 
                  required
                  value={formData.name}
                  onChange={e => setFormData({...formData, name: e.target.value})}
                  className="w-full px-4 py-3.5 bg-sajal-neutral2/30 border border-sajal-neutral1 focus:border-sajal-accent focus:ring-4 focus:ring-sajal-accent/10 outline-none text-sajal-text text-sm transition-all rounded-xl placeholder:text-sajal-text/40 font-medium"
                  placeholder="Your Name"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-bold text-sajal-text mb-2">{t("form.phone")} *</label>
                <input 
                  type="tel" 
                  id="phone" 
                  required
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  className="w-full px-4 py-3.5 bg-sajal-neutral2/30 border border-sajal-neutral1 focus:border-sajal-accent focus:ring-4 focus:ring-sajal-accent/10 outline-none text-sajal-text text-sm transition-all rounded-xl placeholder:text-sajal-text/40 font-medium"
                  placeholder="+91"
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="email" className="block text-sm font-bold text-sajal-text mb-2">{t("form.email")} (Optional)</label>
              <input 
                type="email" 
                id="email" 
                value={formData.email}
                onChange={e => setFormData({...formData, email: e.target.value})}
                className="w-full px-4 py-3.5 bg-sajal-neutral2/30 border border-sajal-neutral1 focus:border-sajal-accent focus:ring-4 focus:ring-sajal-accent/10 outline-none text-sajal-text text-sm transition-all rounded-xl placeholder:text-sajal-text/40 font-medium"
                placeholder="you@example.com"
              />
            </div>
            
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-sajal-text mb-2 flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-sajal-accent" /> {t("Appointment Date")} *
                </label>
                <input 
                  type="date"
                  required
                  min={today}
                  value={appointmentDate}
                  onChange={e => setAppointmentDate(e.target.value)}
                  className="w-full px-4 py-3.5 bg-sajal-neutral2/30 border border-sajal-neutral1 focus:border-sajal-accent focus:ring-4 focus:ring-sajal-accent/10 outline-none text-sajal-text text-sm transition-all rounded-xl font-medium"
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-sajal-text mb-2 flex items-center gap-2">
                  <Clock className="w-4 h-4 text-sajal-accent" /> {t("Time Slot")} *
                </label>
                <div className="relative">
                  <select
                    required
                    disabled={!appointmentDate}
                    value={appointmentTime}
                    onChange={e => setAppointmentTime(e.target.value)}
                    className="w-full px-4 py-3.5 bg-sajal-neutral2/30 border border-sajal-neutral1 focus:border-sajal-accent focus:ring-4 focus:ring-sajal-accent/10 outline-none text-sajal-text text-sm transition-all rounded-xl font-medium appearance-none disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <option value="" disabled>{t("Select a time slot")}</option>
                    {TIME_SLOTS.map(slot => {
                      const count = slotCounts[slot] || 0;
                      const isFull = count >= 5;
                      return (
                        <option key={slot} value={slot} disabled={isFull}>
                          {slot} {isFull ? `(${t("Full")})` : ''}
                        </option>
                      );
                    })}
                  </select>
                  <div className="absolute inset-y-0 right-0 flex items-center px-4 pointer-events-none text-sajal-text/50">
                    <svg className="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" /></svg>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-bold text-sajal-text mb-2">{t("form.message")} *</label>
              <textarea 
                id="message" 
                rows={4}
                required
                value={formData.message}
                onChange={e => setFormData({...formData, message: e.target.value})}
                className="w-full px-4 py-3.5 bg-sajal-neutral2/30 border border-sajal-neutral1 focus:border-sajal-accent focus:ring-4 focus:ring-sajal-accent/10 outline-none text-sajal-text text-sm transition-all rounded-xl resize-none placeholder:text-sajal-text/40 font-medium"
                placeholder="Describe your request in detail..."
              ></textarea>
            </div>

            <div className="pt-4 flex flex-col sm:flex-row gap-4 items-center">
              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto flex-1 py-4 px-6 bg-sajal-secondary text-white text-base font-bold rounded-xl hover:bg-sajal-primary hover:shadow-lg hover:shadow-sajal-secondary/25 transition-all outline-none focus:ring-4 focus:ring-sajal-secondary/20 active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isSubmitting ? (t("form.submitting") || 'Sending...') : (t("form.submit") || 'Send Request')} <Send className="w-5 h-5" />
              </button>

              <div className="relative w-full sm:w-auto flex-1">
                <button 
                  type="button"
                  onClick={() => setShowContact(!showContact)}
                  className="w-full py-4 px-6 bg-sajal-neutral2 text-sajal-primary border border-sajal-neutral1 text-base font-bold rounded-xl hover:bg-sajal-neutral1 transition-all outline-none flex items-center justify-center gap-2"
                >
                  <Phone className="w-5 h-5 text-sajal-accent" /> Live Contact
                </button>
                
                {showContact && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    className="absolute bottom-full mb-3 left-0 w-full bg-slate-900 rounded-xl p-3 shadow-2xl z-10 border border-slate-700 flex flex-col gap-2"
                  >
                     <div className="text-center text-xs font-bold text-slate-400 mb-1">Contact Sajalda</div>
                     <div className="flex justify-center font-mono text-white text-lg font-bold mb-2">+91 91234 56789</div>
                     <div className="grid grid-cols-2 gap-2">
                       <a 
                          href="tel:+919123456789" 
                          className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg text-sm font-bold transition-colors"
                       >
                         <Phone className="w-4 h-4" /> Call
                       </a>
                       <a 
                          href="https://wa.me/919123456789" 
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg text-sm font-bold transition-colors"
                       >
                         <MessageCircle className="w-4 h-4" /> WhatsApp
                       </a>
                     </div>
                  </motion.div>
                )}
              </div>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}

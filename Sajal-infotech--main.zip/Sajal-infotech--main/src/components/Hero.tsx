import React, { useState, useEffect } from 'react';
import { ArrowRight, Star, ChevronLeft, ChevronRight } from 'lucide-react';
import * as motionClient from 'motion/react-client';
import { AnimatePresence, useScroll, useTransform, motion } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { useSiteSettings } from '../hooks/useSiteSettings';
import { useTranslation } from '../contexts/LanguageContext';
import { BlurText } from './BlurText';

const defaultSlides = [
  {
    id: 1,
    title: "Your Complete Digital Solutions Hub",
    badge: "Top Rated Cyber Cafe",
    description: "From online forms, flight tickets, and passport photos to high-speed internet browsing—we've got everything covered seamlessly.",
    image: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?q=80&w=1920&auto=format&fit=crop",
    primaryCta: "Explore Services",
    primaryHref: "#services",
    secondaryCta: "Visit Store",
    secondaryHref: "#contact"
  },
  {
    id: 2,
    title: "Fast & Reliable Internet Access",
    badge: "High-Speed Surfing",
    description: "Enjoy fast and secure internet browsing for your daily needs, emails, research, and casual surfing in a comfortable environment.",
    image: "https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=1920&auto=format&fit=crop",
    primaryCta: "Visit Store",
    primaryHref: "#contact",
    secondaryCta: "Our Services",
    secondaryHref: "#services"
  },
  {
    id: 3,
    title: "Hassle-Free E-Governance & Forms",
    badge: "Fast & Accurate Services",
    description: "Quick assistance with Aadhaar updates, PAN card applications, scholarships, and various online college admission forms.",
    image: "https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?q=80&w=1920&auto=format&fit=crop",
    primaryCta: "Get Assistance",
    primaryHref: "#contact",
    secondaryCta: "Our Services",
    secondaryHref: "#services"
  },
  {
    id: 4,
    title: "Instant Ticket Booking & Utilities",
    badge: "Travel & Bill Payments",
    description: "Secure and fast booking for flights and trains. Quick mobile recharges and utility bill payments done under one roof instantly.",
    image: "https://images.unsplash.com/photo-1436491865332-7a61e109cc05?q=80&w=1920&auto=format&fit=crop",
    primaryCta: "Book Tickets",
    primaryHref: "#contact",
    secondaryCta: "Learn More",
    secondaryHref: "#services"
  }
];

export default function Hero() {
  const { settings } = useSiteSettings();
  const slides = settings?.slides?.length ? settings.slides : defaultSlides;
  const { t } = useTranslation();
  const navigate = useNavigate();
  
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 800], ['0%', '15%']);

  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(1);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [isPaused, setIsPaused] = useState(false);

  const minSwipeDistance = 50;

  const nextSlide = () => {
    setDirection(1);
    setCurrent((prev) => (prev + 1) % slides.length);
  };
  
  const prevSlide = () => {
    setDirection(-1);
    setCurrent((prev) => (prev - 1 + slides.length) % slides.length);
  };

  useEffect(() => {
    if (isPaused) return; // Pause timer if interaction is happening
    
    // Auto slide every 4 seconds
    const timer = setInterval(() => {
      nextSlide();
    }, 4000);
    return () => clearInterval(timer);
  }, [slides.length, isPaused]);

  const onTouchStart = (e: React.TouchEvent) => {
    setIsPaused(true);
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    setIsPaused(false);
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;
    
    if (isLeftSwipe) {
      nextSlide();
    }
    if (isRightSwipe) {
      prevSlide();
    }
  };

  const handleNavigation = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('tel:') || href.startsWith('mailto:')) {
      return;
    }
    
    e.preventDefault();
    
    // Check if the link contains a hash for scrolling
    if (href.includes('#')) {
      const parts = href.split('#');
      const hash = '#' + parts[1];
      const path = parts[0];
      
      // If we're already on the correct path (or it's just a hash), scroll
      if (path === '' || path === '/' || window.location.pathname === path) {
        const el = document.querySelector(hash);
        if (el) {
           const top = el.getBoundingClientRect().top + window.scrollY;
           window.scrollTo({ top: top - 110, behavior: 'smooth' });
        } else {
          window.location.hash = hash;
          setTimeout(() => {
            const elAfter = document.querySelector(hash);
            if (elAfter) {
               const topAfter = elAfter.getBoundingClientRect().top + window.scrollY;
               window.scrollTo({ top: topAfter - 110, behavior: 'smooth' });
            }
          }, 100);
        }
      } else {
        // Need to navigate and let the page handle the scroll
        navigate(href);
      }
    } else if (href.startsWith('/')) {
      navigate(href);
    } else {
      window.open(href, '_blank');
    }
  };

  return (
    <section 
      id="home" 
      className="relative w-full overflow-hidden group bg-slate-900 mt-[68px] md:mt-[100px]"
      style={{ aspectRatio: '16/9', maxHeight: '100vh' }}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Slider Track */}
      <div 
         className="absolute inset-0 w-full h-full overflow-hidden"
         onTouchStart={onTouchStart}
         onTouchMove={onTouchMove}
         onTouchEnd={onTouchEnd}
      >
        <AnimatePresence initial={false} custom={direction} mode="popLayout">
           <motionClient.div
             key={current}
             custom={direction}
             variants={{
               enter: (dir: number) => ({
                 x: dir > 0 ? "100%" : "-100%",
                 opacity: 0,
                 zIndex: 0
               }),
               center: {
                 x: 0,
                 opacity: 1,
                 zIndex: 10
               },
               exit: (dir: number) => ({
                 x: dir < 0 ? "100%" : "-100%",
                 opacity: 0,
                 zIndex: 0
               })
             }}
             initial="enter"
             animate="center"
             exit="exit"
             transition={{
               x: { type: "spring", stiffness: 300, damping: 30 },
               opacity: { duration: 0.2 }
             }}
             className="absolute inset-0 w-full h-full"
           >
              {/* Background Image & Overlays */}
              <div className="absolute inset-0 overflow-hidden bg-slate-900">
                <motion.img 
                   style={{ y }}
                   src={slides[current].image || undefined} 
                   initial={{ scale: 1 }}
                   animate={{ scale: 1.02 }}
                   transition={{ duration: 15, ease: "linear" }}
                   className="absolute inset-0 w-full h-full object-cover" 
                   alt={t(slides[current].title)} 
                />
              </div>
              
              {/* Content */}
              <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-center pointer-events-none">
                 <div className="max-w-xl md:max-w-2xl mt-4 sm:mt-8 pointer-events-auto py-6 drop-shadow-lg flex flex-col justify-center">
                      <motionClient.div 
                        initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} 
                        animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} 
                        transition={{ duration: 0.5, delay: 0.2 }}
                        className="liquid-glass inline-flex items-center gap-2.5 p-1 pr-4 rounded-full mb-5 sm:mb-7 self-start"
                      >
                        <span className="flex items-center justify-center w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-white text-sajal-primary shrink-0">
                          <Star className="h-3.5 w-3.5 sm:h-4 sm:w-4 fill-sajal-primary" />
                        </span>
                        <span className="text-[11px] sm:text-xs font-bold text-white tracking-wide uppercase">{t(slides[current].badge)}</span>
                      </motionClient.div>
                      
                      <BlurText 
                        text={t(slides[current].title)} 
                        className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight mb-3 sm:mb-5 leading-tight [text-shadow:_0_2px_10px_rgb(0_0_0_/_0.8)]"
                        delayOffset={0.3}
                      />
                      
                      <motionClient.p 
                        initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} 
                        animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} 
                        transition={{ duration: 0.6, delay: 0.7, ease: "easeOut" }}
                        className="text-sm sm:text-base lg:text-lg text-white/90 mb-6 sm:mb-10 leading-snug sm:leading-relaxed max-w-lg font-medium line-clamp-3 [text-shadow:_0_1px_5px_rgb(0_0_0_/_0.8)]"
                      >
                        {t(slides[current].description)}
                      </motionClient.p>

                      <motionClient.div 
                        initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} 
                        animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} 
                        transition={{ duration: 0.6, delay: 0.9, ease: "easeOut" }}
                        className="flex flex-wrap sm:flex-row gap-3 sm:gap-4 mb-4 sm:mb-8"
                      >
                        <a
                          href={slides[current].primaryHref}
                          onClick={(e) => handleNavigation(e, slides[current].primaryHref)}
                          className="liquid-glass-strong inline-flex justify-center items-center gap-2 px-6 py-3 sm:px-8 sm:py-3.5 text-sm sm:text-base font-bold text-white rounded-full transition-all active:scale-95 group/btn"
                        >
                          {t(slides[current].primaryCta)}
                          <ArrowRight className="h-4 w-4 sm:h-5 sm:w-5 group-hover/btn:translate-x-1 transition-transform" />
                        </a>
                        <a
                          href={slides[current].secondaryHref}
                          onClick={(e) => handleNavigation(e, slides[current].secondaryHref)}
                          className="liquid-glass inline-flex justify-center items-center gap-2 px-6 py-3 sm:px-8 sm:py-3.5 text-sm sm:text-base font-bold text-white/90 rounded-full transition-all active:scale-95"
                        >
                          {t(slides[current].secondaryCta)}
                        </a>
                      </motionClient.div>
                 </div>
              </div>
           </motionClient.div>
        </AnimatePresence>
      </div>

      {/* Navigation Controls (Visible on hover on Desktop) */}
      <button 
         onClick={prevSlide} 
         className="absolute left-4 sm:left-8 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-white/5 hover:bg-white/20 text-white backdrop-blur-md border border-white/10 hover:border-white/30 transition-all opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100 hidden md:block"
         aria-label="Previous slide"
      >
         <ChevronLeft className="w-8 h-8" />
      </button>
      <button 
         onClick={nextSlide} 
         className="absolute right-4 sm:right-8 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-white/5 hover:bg-white/20 text-white backdrop-blur-md border border-white/10 hover:border-white/30 transition-all opacity-0 group-hover:opacity-100 scale-90 group-hover:scale-100 hidden md:block"
         aria-label="Next slide"
      >
         <ChevronRight className="w-8 h-8" />
      </button>

    </section>
  );
}
import { useState, useEffect } from 'react';
import { ref, onValue } from 'firebase/database';
import { db } from '../lib/firebase';

export interface SiteSettings {
  logoUrl?: string;
  theme?: string;
  isStoreClosed?: boolean;
  slides?: {
    id: number;
    badge: string;
    title: string;
    description: string;
    primaryCta: string;
    primaryHref: string;
    secondaryCta: string;
    secondaryHref: string;
    image: string;
  }[];
}

export function useSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings | null>(() => {
    try {
      const cached = localStorage.getItem('siteSettings');
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  });
  const [isLoaded, setIsLoaded] = useState(() => {
    try {
      return !!localStorage.getItem('siteSettings');
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const settingsRef = ref(db, 'settings/site');
    const unsub = onValue(settingsRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setSettings(val);
        try {
          localStorage.setItem('siteSettings', JSON.stringify(val));
        } catch (e) {
          console.warn('Failed to cache site settings in localStorage due to size limits', e);
          // Try caching without base64 images if possible
          try {
            const strippedVal = { ...val };
            if (strippedVal.slides) {
              strippedVal.slides = strippedVal.slides.map((s: any) => ({
                ...s,
                image: (s.image && s.image.length > 500) ? '' : s.image
              }));
            }
            if (strippedVal.logoUrl && strippedVal.logoUrl.length > 500) {
              strippedVal.logoUrl = '';
            }
            localStorage.setItem('siteSettings', JSON.stringify(strippedVal));
          } catch (e2) {
            console.warn('Still failed to cache stripped site settings', e2);
          }
        }
      }
      setIsLoaded(true);
    });

    return () => unsub();
  }, []);

  return { settings, isLoaded };
}

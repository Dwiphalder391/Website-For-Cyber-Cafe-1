import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDRP3ax7hd_nxHmy5ZHh5emD8jZyy-jqNA",
  authDomain: "messageing-alp.firebaseapp.com",
  databaseURL: "https://messageing-alp-default-rtdb.firebaseio.com",
  projectId: "messageing-alp",
  storageBucket: "messageing-alp.firebasestorage.app",
  messagingSenderId: "341679570146",
  appId: "1:341679570146:web:9406296055e4ad5d6ff2bb",
  measurementId: "G-7XW99LFKQK"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getDatabase(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();

export const themes = {
  default: {
    name: 'Classic Earth',
    colors: {
      primary: '#5D5646',
      secondary: '#A07D54',
      neutral1: '#DFD4C3',
      neutral2: '#F5F2EB', // Lighter for better contrast
      accent: '#3E5974',
      text: '#333333', // Darker text for readability
    }
  },
  corporate: {
    name: 'Corporate Blue',
    colors: {
      primary: '#1E3A8A',    // Deep Blue
      secondary: '#3B82F6',  // Bright Blue
      neutral1: '#E0E7FF',   // Very light blue
      neutral2: '#F8FAFC',   // Off-white slate
      accent: '#10B981',     // Emerald green accent
      text: '#0F172A',       // Slate 900
    }
  },
  obsidian: {
    name: 'Obsidian Tech',
    colors: {
      primary: '#09090B',    // Zinc 950
      secondary: '#6366F1',  // Indigo 500
      neutral1: '#E0E7FF',   // Indigo 100
      neutral2: '#FAFAFA',   // Neutral 50
      accent: '#F43F5E',     // Rose 500
      text: '#18181B',       // Zinc 900
    }
  },
  jade: {
    name: 'Jade Pebble',
    colors: {
      primary: '#2F4F4F',    // Dark Slate Gray
      secondary: '#7B9669',  // Calm Green
      neutral1: '#DCE6D5',   // Very light green
      neutral2: '#F4F7F2',   // Off-white green
      accent: '#EAB308',     // Yellow accent
      text: '#1C2922',       // Very dark green
    }
  },
  ruby: {
    name: 'Ruby Elegance',
    colors: {
      primary: '#500724',    // Rose 950
      secondary: '#E11D48',  // Rose 600
      neutral1: '#FFE4E6',   // Rose 100
      neutral2: '#FFF1F2',   // Rose 50
      accent: '#8B5CF6',     // Violet 500
      text: '#2C101A',
    }
  },
  sunrise: {
    name: 'Sunrise Blend',
    colors: {
      primary: '#4f252a',
      secondary: '#F1745E',
      neutral1: '#FCE7E4',
      neutral2: '#FFF9F8',
      accent: '#E06464',
      text: '#2D1518',
    }
  },
  monochrome: {
    name: 'Monochrome',
    colors: {
      primary: '#000000',
      secondary: '#525252',
      neutral1: '#E5E5E5',
      neutral2: '#FFFFFF',
      accent: '#000000',
      text: '#000000',
    }
  }
};

export type ThemeKey = keyof typeof themes;


import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

export type LanguageCode = 'en' | 'bn' | 'hi';

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string) => string;
}

const translations: Record<LanguageCode, Record<string, string>> = {
  en: {
    "nav.home": "Home",
    "nav.services": "Our Services",
    "nav.contact": "Contact",
    "nav.my_apps": "My Applications",
    "nav.admin": "Admin Panel",
    "nav.login": "Sign Up / Login",
    "nav.logout": "Logout",
    "nav.support": "Get Support",
    "Today Store is Off": "Today Store is Off",
    "Exit Application": "Exit Application",
    "Are you sure you want to exit the application?": "Are you sure you want to exit the application?",
    "No": "No",
    "Yes": "Yes",
    "Appointment Date": "Appointment Date",
    "Time Slot": "Time Slot",
    "Select a time slot": "Select a time slot",
    "Full": "Full",
    "Sorry, our cyber cafe is closed today. You can still submit requests for future dates, and we will process them when we open.": "Sorry, our cyber cafe is closed today. You can still submit requests for future dates, and we will process them when we open.",
    "Continue to Website": "Continue to Website",
    "home.hero.title": "Welcome to Sajal Infotech",
    "home.hero.subtitle": "Digital services at your doorstep",
    "services.title": "Our Services",
    "services.subtitle": "What We Offer",
    "services.desc": "From essential document processes and travel bookings to high-speed internet surfing, we provide reliable, low-cost digital services customized to your needs.",
    "services.view_all": "View All Services",
    "Online Forms & Applications": "Online Forms & Applications",
    "College admissions, scholarships, exam forms, and various online form fill-ups managed accurately.": "College admissions, scholarships, exam forms, and various online form fill-ups managed accurately.",
    "E-Governance & IDs": "E-Governance & IDs",
    "Aadhaar updates, PAN card applications, and registrations for various Government schemes.": "Aadhaar updates, PAN card applications, and registrations for various Government schemes.",
    "Travel & Ticketing": "Travel & Ticketing",
    "Train and flight ticket reservations, cancellation assistance, and detailed travel itinerary planning.": "Train and flight ticket reservations, cancellation assistance, and detailed travel itinerary planning.",
    "Print & Photocopy": "Print & Photocopy",
    "High-quality color/black-and-white printing, large volume photocopying, and instant document lamination.": "High-quality color/black-and-white printing, large volume photocopying, and instant document lamination.",
    "Document Typing & CVs": "Document Typing & CVs",
    "Professional resume/CV creation, formatting, computer typing in English & Bengali, and assignments.": "Professional resume/CV creation, formatting, computer typing in English & Bengali, and assignments.",
    "Internet Browsing": "Internet Browsing",
    "High-speed internet access for daily surfing, emails, research, and general online activities.": "High-speed internet access for daily surfing, emails, research, and general online activities.",
    "Utility Bill Payments": "Utility Bill Payments",
    "Instant mobile recharges, electricity bill, water bill, and other municipal bill payment deposits.": "Instant mobile recharges, electricity bill, water bill, and other municipal bill payment deposits.",
    "Passport Size Photos": "Passport Size Photos",
    "Instant clicking, retouching, and printing of passport/stamp size photos for all official requirements.": "Instant clicking, retouching, and printing of passport/stamp size photos for all official requirements.",
    "form.name": "Full Name",
    "form.phone": "Phone Number",
    "form.email": "Email Address",
    "form.message": "Message / Details",
    "form.submit": "Submit Request",
    "form.submitting": "Submitting...",
    "form.success": "Your request has been submitted successfully!",
    "Your Digital Partner": "Your Digital Partner",
    "Bringing government & private online services closer to you. Reliable, fast, and secure.": "Bringing government & private online services closer to you. Reliable, fast, and secure.",
    "Apply Now": "Apply Now",
    "Learn More": "Learn More",
    "Explore Services": "Explore Services",
    "Visit Store": "Visit Store",
    "Get Assistance": "Get Assistance",
    "Book Tickets": "Book Tickets",
    "Your Complete Digital Solutions Hub": "Your Complete Digital Solutions Hub",
    "Top Rated Cyber Cafe": "Top Rated Cyber Cafe",
    "From online forms, flight tickets, and passport photos to high-speed internet browsing—we've got everything covered seamlessly.": "From online forms, flight tickets, and passport photos to high-speed internet browsing—we've got everything covered seamlessly.",
    "Fast & Reliable Internet Access": "Fast & Reliable Internet Access",
    "High-Speed Surfing": "High-Speed Surfing",
    "Enjoy fast and secure internet browsing for your daily needs, emails, research, and casual surfing in a comfortable environment.": "Enjoy fast and secure internet browsing for your daily needs, emails, research, and casual surfing in a comfortable environment.",
    "Hassle-Free E-Governance & Forms": "Hassle-Free E-Governance & Forms",
    "Fast & Accurate Services": "Fast & Accurate Services",
    "Quick assistance with Aadhaar updates, PAN card applications, scholarships, and various online college admission forms.": "Quick assistance with Aadhaar updates, PAN card applications, scholarships, and various online college admission forms.",
    "Instant Ticket Booking & Utilities": "Instant Ticket Booking & Utilities",
    "Travel & Bill Payments": "Travel & Bill Payments",
    "Secure and fast booking for flights and trains. Quick mobile recharges and utility bill payments done under one roof instantly.": "Secure and fast booking for flights and trains. Quick mobile recharges and utility bill payments done under one roof instantly.",
    "Quick Links": "Quick Links",
    "Phone": "Phone",
    "Email": "Email",
    "Sajal Infotech": "Sajal Infotech",
    "View our Justdial Reviews": "View our Justdial Reviews",
    "Privacy Policy": "Privacy Policy",
    "Terms of Service": "Terms of Service",
    "All rights reserved.": "All rights reserved.",
    "Your trusted local partner for daily internet services, documentation, flight/train bookings, and high-speed internet browsing in Kadambagachi, Kolkata.": "Your trusted local partner for daily internet services, documentation, flight/train bookings, and high-speed internet browsing in Kadambagachi, Kolkata."
  },
  bn: {
    "nav.home": "হোম",
    "nav.services": "আমাদের পরিষেবা",
    "nav.contact": "যোগাযোগ",
    "nav.my_apps": "আমার আবেদনপত্র",
    "nav.admin": "অ্যাডমিন প্যানেল",
    "nav.login": "সাইন আপ / লগইন",
    "nav.logout": "লগআউট",
    "nav.support": "সাহায্য নিন",
    "Today Store is Off": "আজকে দোকান বন্ধ",
    "Exit Application": "অ্যাপ্লিকেশন থেকে প্রস্থান করুন",
    "Are you sure you want to exit the application?": "আপনি কি অ্যাপ্লিকেশন থেকে বেরিয়ে যেতে চান?",
    "No": "না",
    "Yes": "হ্যাঁ",
    "Appointment Date": "অ্যাপয়েন্টমেন্টের তারিখ",
    "Time Slot": "সময়",
    "Select a time slot": "একটি সময় চয়ন করুন",
    "Full": "বুকিং ফুল",
    "Sorry, our cyber cafe is closed today. You can still submit requests for future dates, and we will process them when we open.": "দুঃখিত, আজ আমাদের সাইবার ক্যাফে বন্ধ। তবে, আপনি আগামী দিনের জন্য ফর্ম পূরণ করতে পারেন এবং আমরা দোকান খুললেই আপনার কাজ করবো।",
    "Continue to Website": "ওয়েবসাইটে চালিয়ে যান",
    "home.hero.title": "সজল ইনফোটেক-এ স্বাগতম",
    "home.hero.subtitle": "ডিজিটাল পরিষেবা আপনার দোরগোড়ায়",
    "services.title": "আমাদের পরিষেবা",
    "services.subtitle": "আমরা যা প্রদান করি",
    "services.desc": "প্রয়োজনীয় ডকুমেন্ট প্রসেসিং এবং ট্রাভেল বুকিং থেকে শুরু করে দ্রুত গতির ইন্টারনেট সার্ফিং পর্যন্ত, আমরা আপনার প্রয়োজন অনুযায়ী নির্ভরযোগ্য ও স্বল্প মূল্যের ডিজিটাল পরিষেবা প্রদান করি।",
    "services.view_all": "সকল পরিষেবা দেখুন",
    "Online Forms & Applications": "অনলাইন ফর্ম ও অ্যাপ্লিকেশন",
    "College admissions, scholarships, exam forms, and various online form fill-ups managed accurately.": "কলেজে ভর্তি, স্কলারশিপ, পরীক্ষার ফর্ম এবং বিভিন্ন অনলাইন ফর্ম নির্ভুলভাবে পূরণ করা হয়।",
    "E-Governance & IDs": "ই-গভর্নেন্স এবং পরিচয়পত্র",
    "Aadhaar updates, PAN card applications, and registrations for various Government schemes.": "আধার কার্ড আপডেট, প্যান কার্ডের আবেদন এবং বিভিন্ন সরকারি প্রকল্পের জন্য রেজিস্ট্রেশন।",
    "Travel & Ticketing": "ভ্রমণ ও টিকিট",
    "Train and flight ticket reservations, cancellation assistance, and detailed travel itinerary planning.": "ট্রেন এবং ফ্লাইটের টিকিট বুকিং, বাতিলকরণ সহায়তা এবং বিস্তারিত ভ্রমণের পরিকল্পনা।",
    "Print & Photocopy": "প্রিন্ট ও ফটোকপি",
    "High-quality color/black-and-white printing, large volume photocopying, and instant document lamination.": "উচ্চমানের রঙিন/সাদাকালো প্রিন্ট, বড় ভলিউম ফটোকপি এবং দ্রুত ডকুমেন্ট ল্যামিনেশন।",
    "Document Typing & CVs": "ডকুমেন্ট টাইপিং এবং সিভি",
    "Professional resume/CV creation, formatting, computer typing in English & Bengali, and assignments.": "পেশাদার রেজুমে/সিভি তৈরি, ফরম্যাটিং, ইংরেজি ও বাংলায় কম্পিউটার টাইপিং এবং অ্যাসাইনমেন্ট।",
    "Internet Browsing": "ইন্টারনেট ব্রাউজিং",
    "High-speed internet access for daily surfing, emails, research, and general online activities.": "দৈনন্দিন সার্ফিং, ইমেল, গবেষণা এবং অন্যান্য অনলাইন কাজের জন্য দ্রুত গতির ইন্টারনেট অ্যাক্সেস।",
    "Utility Bill Payments": "ইউটিলিটি বিল পেমেন্ট",
    "Instant mobile recharges, electricity bill, water bill, and other municipal bill payment deposits.": "দ্রুত মোবাইল রিচার্জ, ইলেকট্রিক বিল, জলের বিল এবং অন্যান্য মিউনিসিপ্যাল বিল পেমেন্ট।",
    "Passport Size Photos": "পাসপোর্ট সাইজ ছবি",
    "Instant clicking, retouching, and printing of passport/stamp size photos for all official requirements.": "সমস্ত অফিসিয়াল কাজের জন্য সঙ্গে সঙ্গে ছবি তোলা, রিটাচিং এবং পাসপোর্ট/স্ট্যাম্প সাইজের ছবি প্রিন্ট।",
    "form.name": "পুরো নাম",
    "form.phone": "ফোন নম্বর",
    "form.email": "ইমেইল অ্যাড্রেস",
    "form.message": "বার্তা / বিস্তারিত",
    "form.submit": "আবেদন জমা দিন",
    "form.submitting": "জমা হচ্ছে...",
    "form.success": "আপনার অনুরোধ সফলভাবে জমা দেওয়া হয়েছে!",
    "Your Digital Partner": "আপনার ডিজিটাল পার্টনার",
    "Bringing government & private online services closer to you. Reliable, fast, and secure.": "সরকারি এবং বেসরকারি অনলাইন পরিষেবাগুলি আপনার আরও কাছে নিয়ে আসছি। নির্ভরযোগ্য, দ্রুত এবং সুরক্ষিত।",
    "Apply Now": "এখনই আবেদন করুন",
    "Learn More": "আরও জানুন",
    "Explore Services": "পরিষেবাগুলো দেখুন",
    "Visit Store": "দোকানে আসুন",
    "Get Assistance": "সহায়তা নিন",
    "Book Tickets": "টিকিট বুকিং",
    "Your Complete Digital Solutions Hub": "আপনার সম্পূর্ণ ডিজিটাল সমাধানের হাব",
    "Top Rated Cyber Cafe": "শীর্ষ রেটযুক্ত সাইবার ক্যাফে",
    "From online forms, flight tickets, and passport photos to high-speed internet browsing—we've got everything covered seamlessly.": "অনলাইন ফর্ম, ফ্লাইটের টিকিট এবং পাসপোর্ট সাইজ ছবি থেকে শুরু করে উচ্চ গতির ইন্টারনেট ব্রাউজিং - আমরা সব কিছু মসৃণভাবে প্রদান করি।",
    "Fast & Reliable Internet Access": "দ্রুত এবং নির্ভরযোগ্য ইন্টারনেট অ্যাক্সেস",
    "High-Speed Surfing": "হাই-স্পিড সার্ফিং",
    "Enjoy fast and secure internet browsing for your daily needs, emails, research, and casual surfing in a comfortable environment.": "আপনার দৈনন্দিন প্রয়োজন, ইমেল, গবেষণা এবং স্বাচ্ছন্দ্যময় পরিবেশে ক্যাজুয়াল সার্ফিংয়ের জন্য দ্রুত এবং নিরাপদ ইন্টারনেট উপভোগ করুন।",
    "Hassle-Free E-Governance & Forms": "ঝামেলামুক্ত ই-গভর্নেন্স এবং ফর্ম",
    "Fast & Accurate Services": "দ্রুত এবং নির্ভুল পরিষেবা",
    "Quick assistance with Aadhaar updates, PAN card applications, scholarships, and various online college admission forms.": "আধার আপডেট, প্যান কার্ডের আবেদন, স্কলারশিপ এবং বিভিন্ন অনলাইন কলেজ ভর্তির ফর্মের জন্য দ্রুত সহায়তা।",
    "Instant Ticket Booking & Utilities": "তাত্ক্ষণিক টিকিট বুকিং এবং ইউটিলিটি",
    "Travel & Bill Payments": "ভ্রমণ এবং বিল পেমেন্ট",
    "Secure and fast booking for flights and trains. Quick mobile recharges and utility bill payments done under one roof instantly.": "ফ্লাইট এবং ট্রেনের জন্য সুরক্ষিত এবং দ্রুত বুকিং। দ্রুত মোবাইল রিচার্জ এবং ইউটিলিটি বিল পেমেন্ট এক ছাদের নিচে তাৎক্ষণিকভাবে করা হয়।",
    "Quick Links": "গুরুত্বপূর্ণ লিঙ্ক",
    "Phone": "ফোন",
    "Email": "ইমেইল",
    "Sajal Infotech": "সজল ইনফোটেক",
    "View our Justdial Reviews": "আমাদের জাস্টডায়াল রিভিউ দেখুন",
    "Privacy Policy": "গোপনীয়তা নীতি",
    "Terms of Service": "পরিষেবার শর্তাবলী",
    "All rights reserved.": "সর্বস্বত্ব সংরক্ষিত।",
    "Your trusted local partner for daily internet services, documentation, flight/train bookings, and high-speed internet browsing in Kadambagachi, Kolkata.": "কদম্বগাছি, কলকাতায় আপনার বিশ্বস্ত স্থানীয় পার্টনার। দৈনন্দিন ইন্টারনেট পরিষেবা, ডকুমেন্টেশন, বুকিং এবং ইন্টারনেট ব্রাউজিং এর জন্য।"
  },
  hi: {
    "nav.home": "होम",
    "nav.services": "हमारी सेवाएँ",
    "nav.contact": "संपर्क करें",
    "nav.my_apps": "मेरे आवेदन",
    "nav.admin": "व्यवस्थापक पैनल",
    "nav.login": "साइन अप / लॉगिन",
    "nav.logout": "लॉगआउट",
    "nav.support": "सहायता प्राप्त करें",
    "Today Store is Off": "आज दुकान बंद है",
    "Exit Application": "एप्लिकेशन से बाहर निकलें",
    "Are you sure you want to exit the application?": "क्या आप एप्लिकेशन से बाहर निकलना चाहते हैं?",
    "No": "नहीं",
    "Yes": "हाँ",
    "Appointment Date": "नियुक्ति की तिथि",
    "Time Slot": "समय स्लॉट",
    "Select a time slot": "एक समय चुनें",
    "Full": "फुल",
    "Sorry, our cyber cafe is closed today. You can still submit requests for future dates, and we will process them when we open.": "क्षमा करें, आज हमारा साइबर कैफे बंद है। आप अन्य दिनों के लिए अनुरोध सबमिट कर सकते हैं, और जब हम खोलेंगे तो हम उन्हें प्रोसेस करेंगे।",
    "Continue to Website": "वेबसाइट पर जारी रखें",
    "home.hero.title": "सजल इन्फोटेक में आपका स्वागत है",
    "home.hero.subtitle": "डिजिटल सेवाएँ आपके दरवाजे पर",
    "services.title": "हमारी सेवाएँ",
    "services.subtitle": "हम क्या प्रदान करते हैं",
    "services.desc": "आवश्यक दस्तावेज़ प्रक्रियाओं और यात्रा बुकिंग से लेकर हाई-स्पीड इंटरनेट सर्फिंग तक, हम आपकी आवश्यकताओं के अनुसार विश्वसनीय और कम लागत वाली डिजिटल सेवाएँ प्रदान करते हैं।",
    "services.view_all": "सभी सेवाएँ देखें",
    "Online Forms & Applications": "ऑनलाइन फॉर्म और आवेदन",
    "College admissions, scholarships, exam forms, and various online form fill-ups managed accurately.": "कॉलेज में प्रवेश, छात्रवृत्ति, परीक्षा फॉर्म और विभिन्न ऑनलाइन फॉर्म सटीकता से भरे जाते हैं।",
    "E-Governance & IDs": "ई-गवर्नेंस और पहचान पत्र",
    "Aadhaar updates, PAN card applications, and registrations for various Government schemes.": "आधार अपडेट, पैन कार्ड आवेदन और विभिन्न सरकारी योजनाओं के लिए पंजीकरण।",
    "Travel & Ticketing": "यात्रा और टिकट",
    "Train and flight ticket reservations, cancellation assistance, and detailed travel itinerary planning.": "ट्रेन और फ्लाइट टिकट बुकिंग, रद्दीकरण सहायता और विस्तृत यात्रा योजना।",
    "Print & Photocopy": "प्रिंट और फोटोकॉपी",
    "High-quality color/black-and-white printing, large volume photocopying, and instant document lamination.": "उच्च गुणवत्ता वाले रंगीन/ब्लैक-एंड-व्हाइट प्रिंटिंग, बड़ी मात्रा में फोटोकॉपी और तत्काल दस्तावेज़ लेमिनेशन।",
    "Document Typing & CVs": "दस्तावेज़ टाइपिंग और सीवी",
    "Professional resume/CV creation, formatting, computer typing in English & Bengali, and assignments.": "पेशेवर रेज़्यूमे/सीवी निर्माण, स्वरूपण, अंग्रेजी और बंगाली में कंप्यूटर टाइपिंग और असाइनमेंट।",
    "Internet Browsing": "इंटरनेट ब्राउज़िंग",
    "High-speed internet access for daily surfing, emails, research, and general online activities.": "दैनिक सर्फिंग, ईमेल, शोध और अन्य ऑनलाइन गतिविधियों के लिए तेज़ गति वाला इंटरनेट एक्सेस।",
    "Utility Bill Payments": "उपयोगिता बिल भुगतान",
    "Instant mobile recharges, electricity bill, water bill, and other municipal bill payment deposits.": "तुरंत मोबाइल रिचार्ज, बिजली बिल, पानी का बिल और अन्य नगरपालिका बिल भुगतान।",
    "Passport Size Photos": "पासपोर्ट साइज फोटो",
    "Instant clicking, retouching, and printing of passport/stamp size photos for all official requirements.": "सभी आधिकारिक आवश्यकताओं के लिए तुरंत फोटो खींचना, सुधारना और पासपोर्ट/स्टाम्प आकार की तस्वीरें मुद्रित करना।",
    "form.name": "पूरा नाम",
    "form.phone": "फ़ोन नंबर",
    "form.email": "ईमेल पता",
    "form.message": "संदेश / विवरण",
    "form.submit": "अनुरोध सबमिट करें",
    "form.submitting": "सबमिट हो रहा है...",
    "form.success": "आपका अनुरोध सफलतापूर्वक सबमिट कर दिया गया है!",
    "Your Digital Partner": "आपका डिजिटल पार्टनर",
    "Bringing government & private online services closer to you. Reliable, fast, and secure.": "सरकारी और निजी ऑनलाइन सेवाओं को आपके करीब लाना। विश्वसनीय, तेज़ और सुरक्षित।",
    "Apply Now": "अभी आवेदन करें",
    "Learn More": "और जानें",
    "Explore Services": "सेवाएँ देखें",
    "Visit Store": "स्टोर पर जाएं",
    "Get Assistance": "सहायता प्राप्त करें",
    "Book Tickets": "टिकट बुक करें",
    "Your Complete Digital Solutions Hub": "आपका संपूर्ण डिजिटल समाधान केंद्र",
    "Top Rated Cyber Cafe": "टॉप रेटेड साइबर कैफे",
    "From online forms, flight tickets, and passport photos to high-speed internet browsing—we've got everything covered seamlessly.": "ऑनलाइन फॉर्म, फ्लाइट टिकट और पासपोर्ट फोटो से लेकर हाई-स्पीड इंटरनेट ब्राउज़िंग तक—हम सब कुछ आसानी से कवर करते हैं।",
    "Fast & Reliable Internet Access": "तेज़ और विश्वसनीय इंटरनेट पहुँच",
    "High-Speed Surfing": "हाई-स्पीड सर्फिंग",
    "Enjoy fast and secure internet browsing for your daily needs, emails, research, and casual surfing in a comfortable environment.": "अपनी दैनिक ज़रूरतों, ईमेल, शोध और आरामदायक माहौल में सर्फिंग के लिए तेज़ और सुरक्षित इंटरनेट ब्राउज़िंग का आनंद लें।",
    "Hassle-Free E-Governance & Forms": "परेशानी मुक्त ई-गवर्नेंस और फॉर्म",
    "Fast & Accurate Services": "तेज़ और सटीक सेवाएँ",
    "Quick assistance with Aadhaar updates, PAN card applications, scholarships, and various online college admission forms.": "आधार अपडेट, पैन कार्ड आवेदन, छात्रवृत्ति और विभिन्न ऑनलाइन कॉलेज प्रवेश फॉर्म के लिए त्वरित सहायता।",
    "Instant Ticket Booking & Utilities": "त्वरित टिकट बुकिंग और उपयोगिताएँ",
    "Travel & Bill Payments": "यात्रा और बिल भुगतान",
    "Secure and fast booking for flights and trains. Quick mobile recharges and utility bill payments done under one roof instantly.": "उड़ानों और ट्रेनों के लिए सुरक्षित और तेज़ बुकिंग। त्वरित मोबाइल रिचार्ज और उपयोगिता बिल भुगतान एक ही छत के नीचे तुरंत।",
    "Quick Links": "महत्वपूर्ण लिंक",
    "Phone": "फ़ोन",
    "Email": "ईमेल",
    "Sajal Infotech": "सजल इन्फोटेक",
    "View our Justdial Reviews": "हमारी Justdial समीक्षाएं देखें",
    "Privacy Policy": "गोपनीयता नीति",
    "Terms of Service": "सेवा की शर्तें",
    "All rights reserved.": "सर्वाधिकार सुरक्षित।",
    "Your trusted local partner for daily internet services, documentation, flight/train bookings, and high-speed internet browsing in Kadambagachi, Kolkata.": "दैनिक इंटरनेट सेवाओं, दस्तावेज़ीकरण, उड़ान/ट्रेन बुकिंग और हाई-स्पीड इंटरनेट ब्राउज़िंग के लिए कदंबगाछी, कोलकाता में आपका विश्वसनीय स्थानीय भागीदार।"
  }
};

const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  t: (key: string) => key,
});

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<LanguageCode>(() => {
    return (localStorage.getItem('siteLanguage') as LanguageCode) || 'en';
  });

  const [dynamicTranslations, setDynamicTranslations] = useState<Record<string, Record<string, string>>>(() => {
    try {
      const cached = localStorage.getItem('dynamicTranslations');
      return cached ? JSON.parse(cached) : { en: {}, bn: {}, hi: {} };
    } catch {
      return { en: {}, bn: {}, hi: {} };
    }
  });

  const fetchingTranslations = useRef<Set<string>>(new Set());

  const handleSetLanguage = (lang: LanguageCode) => {
    setLanguage(lang);
    localStorage.setItem('siteLanguage', lang);
    localStorage.setItem('languageSelected', 'true');
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const fetchTranslation = async (key: string, targetLang: LanguageCode) => {
    if (!key || typeof key !== 'string') return;
    const fetchKey = `${targetLang}_${key}`;
    if (key.trim().length === 0 || fetchingTranslations.current.has(fetchKey)) return;
    
    fetchingTranslations.current.add(fetchKey);

    try {
      const res = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${targetLang}&dt=t&q=${encodeURIComponent(key)}`);
      if (!res.ok) throw new Error('Network response was not ok');
      const data = await res.json();
      const translatedText = data[0].map((item: any) => item[0]).join('');
      
      if (translatedText && translatedText !== key) {
        setDynamicTranslations(prev => {
          const updated = {
            ...prev,
            [targetLang]: {
              ...(prev[targetLang] || {}),
              [key]: translatedText
            }
          };
          try {
            localStorage.setItem('dynamicTranslations', JSON.stringify(updated));
          } catch (e) {
            console.warn('Failed to cache dynamic translations due to size limits', e);
          }
          return updated;
        });
      }
    } catch (e) {
      console.error("Dynamic translation failed for:", key, e);
      fetchingTranslations.current.delete(fetchKey);
    }
  };

  const t = (key: string) => {
    if (!key) return "";
    
    if (language === 'en') {
      return translations['en']?.[key] || key;
    }
    
    if (translations[language]?.[key]) {
      return translations[language][key];
    }
    
    if (dynamicTranslations[language]?.[key]) {
      return dynamicTranslations[language][key];
    }

    fetchTranslation(key, language);
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
}

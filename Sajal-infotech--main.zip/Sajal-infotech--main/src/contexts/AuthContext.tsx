import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { User, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { ref, get, set, child } from 'firebase/database';
import { auth, db, googleProvider } from '../lib/firebase';
import { toast } from 'react-hot-toast';
import { playSound } from '../lib/sounds';

interface AuthContextType {
  user: User | null;
  isAdmin: boolean;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        // Initialize user in Database
        const userRef = ref(db, `users/${currentUser.uid}`);
        const snapshot = await get(userRef);
        
        if (!snapshot.exists()) {
          // Check if this is the very first user to assign admin
          const usersSnap = await get(ref(db, 'users'));
          const isFirstUser = !usersSnap.exists() || Object.keys(usersSnap.val() || {}).length === 0;
          const role = (isFirstUser || currentUser.email === 'dwiphalder700@gmail.com') ? 'admin' : 'user';
          
          await set(userRef, {
            name: currentUser.displayName,
            email: currentUser.email,
            photoURL: currentUser.photoURL,
            role: role,
            createdAt: Date.now()
          });
          setIsAdmin(role === 'admin');
        } else {
          const userData = snapshot.val();
          if (currentUser.email === 'dwiphalder700@gmail.com' && userData.role !== 'admin') {
             await set(ref(db, `users/${currentUser.uid}/role`), 'admin');
             setIsAdmin(true);
          } else {
             setIsAdmin(userData.role === 'admin');
          }
        }
      } else {
        setIsAdmin(false);
      }
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      playSound('success');
      toast.success("Login Successful!", {
        style: { background: '#10b981', color: '#fff' },
        iconTheme: { primary: '#fff', secondary: '#10b981' },
      });
    } catch (error: any) {
      console.error("Error signing in", error);
      if (error?.code !== 'auth/popup-closed-by-user') {
         toast.error("Login failed. Please try again.");
      }
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      playSound('pop');
      toast("Logged out successfully");
    } catch (error) {
      console.error("Error signing out", error);
    }
  };

  return (
    <AuthContext.Provider value={{ user, isAdmin, loading, signInWithGoogle, logout }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);

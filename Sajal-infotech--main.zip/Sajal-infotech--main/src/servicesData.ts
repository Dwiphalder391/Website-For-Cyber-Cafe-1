export const servicesData = [
  // Banking & Finance
  {
    id: 'money_transfer',
    title: 'Money Transfer & Banking',
    description: 'Secure money transfer, bank deposit, and withdrawal services for all major banks.',
    icon: 'Landmark',
    category: 'Banking & Finance',
  },
  {
    id: 'insurance_premium',
    title: 'LIC & Insurance Premium',
    description: 'Hassle-free premium payment services for LIC and various other insurance policies.',
    icon: 'Shield',
    category: 'Banking & Finance',
  },
  {
    id: 'health_motor_insurance',
    title: 'Health & Motor Insurance',
    description: 'New policies and renewals for two-wheeler, four-wheeler, and health insurance.',
    icon: 'Car',
    category: 'Banking & Finance',
  },
  
  // Legal & Identity Services
  {
    id: 'pan_card',
    title: 'PAN Card Services',
    description: 'New PAN card applications, corrections, and linking services handled precisely.',
    icon: 'IdCard',
    category: 'Legal & Identity Services',
  },
  {
    id: 'passport_visa',
    title: 'Passport & Visa Forms',
    description: 'Accurate form fill-up assistance for new passports, renewals, and visa applications.',
    icon: 'Globe',
    category: 'Legal & Identity Services',
  },
  {
    id: 'affidavit_court',
    title: 'Affidavit & Court Work',
    description: 'Assistance with affidavits, notary, and other court-related documentation.',
    icon: 'Scale',
    category: 'Legal & Identity Services',
  },
  {
    id: 'land_records',
    title: 'Land Information Search',
    description: 'Search and retrieval of land records and property information details.',
    icon: 'MapIcon',
    category: 'Legal & Identity Services',
  },

  // Online Forms & Applications
  {
    id: 'caste_certificate',
    title: 'SC, OBC & ST Certificates',
    description: 'Application processing for Caste certificates including SC, OBC, and ST.',
    icon: 'FileText',
    category: 'Online Forms & Applications',
  },
  {
    id: 'college_admission',
    title: 'College Admission Forms',
    description: 'Online form fill-up for college, university admissions, and competitive exams.',
    icon: 'GraduationCap',
    category: 'Online Forms & Applications',
  },
  {
    id: 'scholarship_forms',
    title: 'Scholarship Applications',
    description: 'Complete guidance and application submission for various educational scholarships.',
    icon: 'BookOpen',
    category: 'Online Forms & Applications',
  },
  {
    id: 'all_online_forms',
    title: 'All Online Form Fill-ups',
    description: 'A to Z online form fill-up services for any government or private sector requirements.',
    icon: 'MousePointer2',
    category: 'Online Forms & Applications',
  },

  // Travel & Ticketing
  {
    id: 'travel_tickets',
    title: 'Train, Bus & Flight Tickets',
    description: 'Instant ticket booking for trains (including Tatkal), buses, and domestic/international flights.',
    icon: 'Ticket',
    category: 'Travel & Ticketing',
  },

  // Utilities & Recharge
  {
    id: 'bill_payments',
    title: 'All Utility Bill Payments',
    description: 'Quick payment of electricity bills, water bills, and other utility services.',
    icon: 'Zap',
    category: 'Utilities & Recharge',
  },
  {
    id: 'mobile_dth_recharge',
    title: 'Mobile & DTH Recharge',
    description: 'Instant recharge for all prepaid/postpaid mobile networks and DTH operators.',
    icon: 'Smartphone',
    category: 'Utilities & Recharge',
  },
  {
    id: 'gas_transfer',
    title: 'Gas Distributor Transfer',
    description: 'Assistance with LPG gas agency transfer and related distributor services.',
    icon: 'Flame',
    category: 'Utilities & Recharge',
  },

  // Printing & Documentation
  {
    id: 'print_xerox',
    title: 'Print & Colour Xerox',
    description: 'High-quality printing, photocopying, and colour Xerox services at affordable rates.',
    icon: 'Printer',
    category: 'Printing & Documentation',
  },
  {
    id: 'lamination_binding',
    title: 'Lamination & Special Binding',
    description: 'Document preservation via lamination and special book binding services.',
    icon: 'Layers',
    category: 'Printing & Documentation',
  },
  {
    id: 'school_projects',
    title: 'School & College Projects',
    description: 'Comprehensive help with school and college project assignments and typing.',
    icon: 'Briefcase',
    category: 'Printing & Documentation',
  },

  // Photography & IT Services
  {
    id: 'photography_restoration',
    title: 'Photos & Restoration',
    description: 'Instant passport photos, DSLR photography, and restoration of old/damaged photos.',
    icon: 'Camera',
    category: 'Photography & IT Services',
  },
  {
    id: 'computer_repair',
    title: 'Computer Repair',
    description: 'Reliable repair and maintenance services for desktop computers and laptops.',
    icon: 'Monitor',
    category: 'Photography & IT Services',
  },
];

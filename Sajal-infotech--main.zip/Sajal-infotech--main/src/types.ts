export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface ReviewItem {
  id: string;
  author: string;
  rating: number;
  text: string;
  date: string;
}
